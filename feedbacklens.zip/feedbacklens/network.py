"""Find this laptop's CURRENT address on the Wi-Fi/LAN so phones and other laptops can reach the apps.
Worked out fresh every time (addresses change when you switch or reconnect Wi-Fi)."""
import os, socket, io


def all_ips():
    """Every usable IPv4 address of this machine, best guess first."""
    ips = []
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))  # no packet is sent; just asks which interface would be used
        ips.append(s.getsockname()[0])
    except Exception:
        pass
    finally:
        s.close()
    try:
        ips += [a[4][0] for a in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET)]
    except Exception:
        pass
    seen, out = set(), []
    for ip in ips:
        if ip not in seen and not ip.startswith(("127.", "169.254.", "0.")):
            seen.add(ip); out.append(ip)
    return out


def lan_ip():
    return os.getenv("PUBLIC_HOST") or (all_ips() or ["127.0.0.1"])[0]


def url(port, path=""):
    return os.getenv(f"URL_{port}") or f"http://{lan_ip()}:{port}{path}"


def qr_png(link):
    import qrcode
    buf = io.BytesIO(); qrcode.make(link, box_size=6, border=2).save(buf, format="PNG")
    return buf.getvalue()
