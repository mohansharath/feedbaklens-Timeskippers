"""FeedbackForm — public form generated from FeedbackLens.  Run: streamlit run feedback_form.py --server.port 8503
Open with ?form=FORM-XXXXXXXX (the link / QR code shown in FeedbackLens → Feedback Forms)."""
import streamlit as st
import db
import theme  # noqa: F401  (shared look)
from client import send_feedback

st.set_page_config(page_title="Feedback", page_icon="📝", layout="centered")
theme.apply(st)
db.init_db()
form_id = st.query_params.get("form")
form = db.get_form(form_id) if form_id else None
if not form:
    st.title("📝 FeedbackForm")
    st.info("This link has no valid form ID. Ask the product team for the form link or QR code.")
    st.stop()

app = db.get_app(form["app_id"]) or {"icon": "", "name": form["app_id"]}
st.title(f"{app['icon']} {form['title']}")
if form["description"]:
    st.caption(form["description"])
if st.session_state.get("done") == form_id:
    st.success("🙏 Thank you! Your feedback has been received.")
    if st.button("Send another response"):
        st.session_state.done = None; st.rerun()
    st.stop()

with st.form("fb"):
    st.markdown("**How would you rate us?**")
    rating = st.feedback("stars")
    area = st.selectbox("Which area is this about?", ["(choose)"] + form["areas"])
    text = st.text_area(form["question"] or "Tell us more", placeholder="e.g. UPI payment failed at checkout")
    user = st.text_input("Email / user ID (optional)")
    if st.form_submit_button("Submit", type="primary"):
        if rating is None and not text.strip():
            st.warning("Please add a rating or a comment.")
        else:
            send_feedback({"app_id": form["app_id"], "form_id": form_id, "source": "feedbackform",
                           "rating": (rating + 1) if rating is not None else None, "feedback_text": text,
                           "product_area": None if area == "(choose)" else area, "user_id": user or None})
            st.session_state.done = form_id; st.rerun()
