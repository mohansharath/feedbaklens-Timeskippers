# 🔎 FeedbackLens
**Turning messy human feedback into prioritised, traceable product decisions.**

Reviews, support chats, surveys and social posts go in. A ranked list of real product problems comes out, and every problem links back to the exact customer messages behind it.

> Most tools stop at *"how do customers feel"* (sentiment). FeedbackLens also answers *"what is broken, who is affected, how badly, is it getting worse, and what's the evidence?"*

---

## Quick start
```bash
pip install -r requirements.txt
python run_all.py              # starts all 4 parts (first run creates the database with ≈5,300 demo records)
```
Or just double-click **`start_windows.bat`** (Windows) or run `./start_mac_linux.sh` (Mac/Linux). If it's working, the sidebar shows an orange **"Version 2.4 · Deep Berry theme"** badge. If you don't see the badge, you're running an old copy: close all old terminal windows and start again from the new folder.
| Part | URL | Who uses it |
|---|---|---|
| **FeedbackLens** dashboard | http://localhost:8501 | Product team |
| **AppBazaar** (mini app store) | http://localhost:8502 | Users rate & review apps |
| **FeedbackForm** (public forms) | http://localhost:8503/?form=FORM-… | Anyone with the link / QR code |
| **API** + Swagger docs | http://localhost:8000/docs | All sources send feedback here |

To reset the demo, delete `data/feedbacklens.db`. You can also upload your own CSV in the dashboard sidebar ("Upload CSV"). Only a `text` column is required.

## 📱 Use on phones and other laptops
Everything runs on **your laptop**. The other devices only open a browser.

1. **Start:** double-click `start_windows.bat`. The first time, it asks for admin permission (click **Yes**) so it can open Windows Firewall for the app.
2. **Read the terminal:** it prints the laptop's *current* address, a self-test (✅ or ❌ for each address), and a QR code. Addresses change when you switch or reconnect Wi-Fi, so always use the links from the latest start and never old ones.
3. **On your own laptop,** always use **http://localhost:8501** (dashboard) and **http://localhost:8502** (AppBazaar).
4. **On a phone or another laptop,** connect to the **same Wi-Fi**, then scan the QR code, or use FeedbackLens sidebar → 📱 *Open on phones*.

| Problem | Fix |
|---|---|
| "Took too long to respond" on the phone | College/office Wi-Fi often blocks device-to-device traffic. Turn on your **phone hotspot**, connect the laptop to it, restart, and use the new address. |
| Still blocked on the same network | Double-click `allow_firewall_windows.bat` (click Yes). It removes Windows' hidden "block Python" rules and opens ports 8000, 8501–8503. |
| Phone is on mobile data / a different network | Install cloudflared once (`winget install --id Cloudflare.cloudflared`), then use `start_public_windows.bat`. It creates public `https://…trycloudflare.com` links, and the QR codes use them automatically. |
| Even localhost doesn't open | The apps aren't running. Check the terminal for a red error. |

## 💰 Impact Forecast (users lost and revenue at risk)
Every prediction is backed by evidence. The prediction steps are in `predict.py`:
| Step | Algorithm | Evidence shown |
|---|---|---|
| **Churn model** (who will leave) | Logistic Regression vs Gradient Boosting. The better 5-fold cross-validated AUC wins. | Test AUC on customers the model never saw, a calibration chart (predicted vs actual), and the top drivers |
| **New users hit next 30 days** | Damped Holt trend, linear trend, 4-week average and "last week repeated" compete on rolling back-tests | Forecast chart with an 80% range, plus back-test error vs a simple guess |
| **Churn caused by the issue** | What-if-fixed: each customer is re-scored with that issue's complaints removed | "Chance of leaving: now → if fixed" |
| **Revenue at risk** | Expected leavers × their own monthly spend (orders ÷ 3 × average order value) | Range from resampling customers (bootstrap) + the forecast range |
| **Historical proof** | The share of affected customers who actually left vs customers with no complaints, with 95% ranges | "3.7× more likely to leave" |

- **Data used:** feedback features (issues experienced, severity, lowest rating, negative messages, said they'd uninstall/switch) + customer activity (`tenure_days, orders_90d, avg_order_value`) + the label `churned` (1/0; blank = outcome not known yet → these are the customers we predict for).
- **Demo data:** in the demo, `data/customers.csv` is generated. In production, connect your orders or CRM table. For an uploaded feedback CSV, upload a customer CSV in the sidebar. If there's no customer data, the tab says so instead of showing guesses.
- The API endpoint is `GET /api/v1/impact`. The Excel download and the decision report also include users lost and revenue at risk.

## Architecture
```
 AppBazaar ─┐
FeedbackForm ┼──► POST /api/v1/feedback (one contract) ──► SQLite (feedback, forms, apps, reviews)
 CSV / API ─┘                                                   │
                                                                ▼
                        FeedbackLens: pipeline → issues → priority → evidence
                                                                │
                              low-confidence items ──► 👨‍💼 Human Review ──► decisions feed back into priority
```
- Sources never know how the analysis works, and FeedbackLens doesn't care where feedback came from. A new source (for example a support bot) only has to call the same API.
- **Processing modes:** *Batch* (default) means new feedback waits until you press **⚙️ Process new feedback**, and the API also processes automatically every 50 records. *Realtime* re-analyses on every change (use the sidebar toggle, or `ANALYSIS_MODE=realtime` for the API).
- If the API is offline, AppBazaar and FeedbackForm write directly to the database, so a live demo never breaks.

## 👨‍💼 Human-in-the-Loop
- The AI scores its own **confidence** for every message using clear rules: no clear product area, matches 2+ areas, too short or vague, mixed sentiment, or a rating that contradicts the text.
- About **88% is handled automatically**. Only uncertain items go to a person, plus *critical* items the AI isn't sure about.
- The reviewer picks **Accept / Edit / Reject**:
  - Edit changes the category or severity.
  - Reject marks the item as a support request, spam and so on, which removes it from the priorities.
  - **"Apply to similar messages"** uses one decision for the whole cluster.
- **The AI's original answer is never overwritten.** The AI answer and the human answer are both stored (the `reviews` table and the audit log).
- An **AI vs Human** panel shows the percent accepted / corrected / rejected and *where* the AI gets corrected.
- Human decisions change the ranking. Example: correct "money deducted but order not placed" from *Payments* to *Orders* and a new Orders issue appears in the priorities.

## 📝 Feedback Forms
In the dashboard, go to Feedback Forms → Create form. Pick a product, a question and the product areas, and you get a **link + QR code**. The customer's chosen area helps the AI when their text is vague. For phones to scan the QR on a local network, set the form address to your laptop's IP (for example `http://192.168.1.5:8503`).

**Optional Claude summaries:** run `pip install anthropic` and `export ANTHROPIC_API_KEY=...`. Then click *"✨ Deeper analysis"* in the Decision Assistant tab. Everything else runs **offline and free**.

---

## Files
`api.py` API · `db.py` database · `pipeline.py` AI engine · `app.py` + `hitl_forms.py` dashboard · `appbazaar.py` · `feedback_form.py` · `client.py` (how sources call the API) · `network.py` (finds your Wi-Fi address, QR codes) · `run_all.py` launcher · `predict.py` + `impact_tab.py` Impact Forecast · `generate_data.py` demo data

## Pipeline (`pipeline.py`)
```
Feedback (reviews · chats · surveys · social)
  → 1. Normalize     keep only what the customer said in chats; fix case, typos, emojis, "sooo!!!"; map GPay/PhonePe → UPI
  → 2. Understand    product area · sentiment (incl. "mixed") · severity 0-4 · segment (UPI/Card/OTP) · business impact · repeats
  → 3. Embed         word + character TF-IDF → LSA vectors (the character part tolerates typos like "paymnt")
  → 4. Cluster       agglomerative clustering (grouping similar messages) inside each area → Area / Sub-issue tree
  → 5. Label         most common wording + distinctive keywords (class-based TF-IDF)
  → 6. Analyse       unique users, rating, weekly spikes (z-score), growth vs the previous 8 weeks, link to a release
  → 7. Prioritise    transparent 0-100 score (below)
  → 8. Insight       what we know · possible trigger · recommended investigation · confidence
```

### Priority score (not a black box)
| Component | Default weight | Measures |
|---|---|---|
| Reach | 35% | **Unique users**, not message count, so one loud user counts once |
| Severity | 30% | Money loss (4) > broken function (3) > slow/annoying (2) > cosmetic (1) |
| Trend | 20% | Recent volume ÷ earlier volume (4× growth or more = full points) |
| Business impact | 15% | Share of messages mentioning refunds, charges, churn or a 1★ rating |

You can change the weights live in the sidebar. The *"Why is each issue ranked here?"* chart shows how many points each component adds.

---

## Dashboard (`app.py`) — 7 screens
1. **📊 Overview:** key metrics, the top problem, and where problems live.
2. **🔥 Priorities:** the ranked table, the score breakdown, and **Loudest complainer vs. real problem**.
3. **📈 Trends:** weekly volume with release markers and emerging-issue alerts.
4. **🔍 Evidence Explorer:** Decision → score → issue → cluster → each original message (searchable and downloadable).
5. **🧠 Decision Assistant:** the insight card, an optional deeper analysis, and a downloadable HTML decision report (print → Save as PDF) + formatted Excel files with plain-English column names.
6. **👨‍💼 Human Review:** the uncertain-items queue, Accept/Edit/Reject, AI vs Human stats, and the audit log.
7. **📝 Feedback Forms:** the form builder, with a link, QR code and response counts.

---

## 3-minute demo script
0. **Live:** hand a judge your phone and have them scan the form QR (or open AppBazaar) and write "PhonePe payment failed, money deducted twice". In FeedbackLens the sidebar shows "🆕 1 new feedback". Press **Process**, and it appears at the top of **Human Review** because it's critical and the AI isn't sure. Correct it live, and the priorities update.
1. *"We have 5,300 messy messages with typos, Hinglish, emojis, chats and bare star ratings."* (Overview)
2. *"The loudest user sent 45 angry messages about font size. That issue reaches 1 person, so it ranks #24. The real #1 is UPI payment failure: 1,000+ different users."* (Priorities → Loudest vs real)
3. *"Payment complaints jumped 3.4× the week of release v4.2. We call it a **possible** trigger, not a proven cause."* (Trends)
4. *"Click the issue and you see every number traced back to real customer quotes."* (Evidence Explorer)
5. *"The PM gets a next step: compare gateway timeouts before and after v4.2 and auto-refund the debited-but-failed orders."* (Decision Assistant → export)

## Judge Q&A
- **How is this different from sentiment analysis?** "I love the app, but payment fails" is positive in tone, but it is still a payment bug. We extract the *issue* and score its impact.
- **Why not just count complaints?** Counting rewards whoever complains most. We count unique users and flag issues where one user sends most of the messages.
- **Does it scale?** TF-IDF + LSA + clustering handles tens of thousands of rows in seconds. For more, swap `embed()` for sentence-transformers and use HDBSCAN or mini-batch clustering.
- **Can it be wrong?** Yes. That's why each message gets a confidence score, uncertain ones go to a human, and every issue shows its evidence and says "possible trigger," not "proven cause."
- **Is the revenue prediction just a guess?** No. It uses a model trained on real past outcomes and tested on customers it never saw (AUC shown). The forecast method is picked by back-testing, and the "caused by the issue" part comes from a what-if comparison. The tab also shows the actual historical churn of affected customers next to customers with no complaints.
- **Doesn't a human reviewing slow it down?** The human only sees about 12% of messages, and one decision can cover a whole cluster.

## Ideas to extend
Sentence-transformer embeddings (multilingual) · LLM tagging per message · Jira/GitHub export · Slack alerts on spikes · Revenue-weighted reach.
