"""Downloadable decision report as a clean, styled HTML page (opens in any browser, print → Save as PDF)."""
from datetime import datetime
from html import escape as e
import pipeline as P
from theme import BERRY, VANILLA, CREAM, INK, MUTED


def _risk(im, x, inr):
    if im is None or x.issue_id not in im.index:
        return ""
    f = im.loc[x.issue_id]
    return (f"<div><b>{f.users_lost_30d:.0f}</b>users likely lost (30 days)</div>"
            f"<div><b>{inr(f.revenue_month)}</b>revenue at risk / month</div>")


def build(problems, df, n=10, title="FeedbackLens — Product Decision Report", imp=None):
    from predict import inr
    im = imp.set_index("issue_id") if imp is not None and len(imp) else None
    cards = []
    for _, x in problems.head(n).iterrows():
        i = P.insight(x)
        why = "".join(f"<li><b>{e(nm)}</b> +{pts} <span>— {e(d)}</span></li>" for nm, pts, d in P.explain(x))
        quotes = "".join(f"<blockquote>“{e(str(df.at[j, 'text'])[:160])}”</blockquote>" for j in x.evidence_ids[:3])
        cards.append(f"""
<section class="card">
  <div class="head"><span class="rank">#{x.priority_rank}</span><h2>{e(x.title)}</h2><span class="score">{x.priority}</span></div>
  <div class="stats"><div><b>{x.unique_users:,}</b>users affected</div><div><b>{x.records:,}</b>feedback records</div>
    <div><b>{x.growth}×</b>trend</div><div><b>{x.severity}/4</b>severity</div>{_risk(im, x, inr)}</div>
  <p><b>What we know:</b> {e(i['what_we_know'])}</p>
  <p><b>Possible trigger:</b> {e(i['possible_trigger'])}</p>
  <p><b>Recommended investigation:</b> {e(i['recommended_investigation'])}</p>
  <details open><summary>Why this priority?</summary><ul>{why}</ul></details>
  <h3>Evidence</h3>{quotes}
</section>""")
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><title>{e(title)}</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
 body{{margin:0;background:{VANILLA};color:{INK};font:15px/1.55 system-ui,-apple-system,Segoe UI,Roboto,sans-serif}}
 header{{background:{BERRY};color:#fff;padding:28px 32px}} header h1{{margin:0;font-size:26px}} header p{{margin:6px 0 0;opacity:.9}}
 main{{max-width:900px;margin:24px auto;padding:0 16px}}
 .card{{background:#fff;border:1px solid {CREAM};border-left:6px solid {BERRY};border-radius:12px;padding:18px 22px;margin:0 0 18px;break-inside:avoid}}
 .head{{display:flex;align-items:center;gap:12px}} .head h2{{flex:1;margin:0;font-size:18px}}
 .rank{{background:{BERRY};color:#fff;border-radius:8px;padding:2px 10px;font-weight:700}}
 .score{{border:2px solid {BERRY};color:{BERRY};border-radius:20px;padding:2px 12px;font-weight:700}}
 .stats{{display:flex;flex-wrap:wrap;gap:10px;margin:14px 0}} .stats div{{flex:1 1 120px;background:{CREAM};border-radius:8px;padding:8px 10px;font-size:12px;color:{MUTED}}}
 .stats b{{display:block;font-size:18px;color:{INK}}}
 blockquote{{margin:6px 0;padding:6px 12px;border-left:3px solid {CREAM};color:{MUTED}}} h3{{font-size:14px;margin:14px 0 4px}}
 ul{{margin:6px 0;padding-left:18px}} li span{{color:{MUTED}}} summary{{cursor:pointer;font-weight:600}}
 footer{{text-align:center;color:{MUTED};font-size:12px;padding:10px 0 30px}}
 @media print{{header{{-webkit-print-color-adjust:exact;print-color-adjust:exact}}}}
</style></head><body>
<header><h1>🔎 {e(title)}</h1><p>Generated {datetime.now():%d %b %Y, %H:%M} · {len(df):,} feedback records · {df.user_id.nunique():,} unique users · top {min(n, len(problems))} of {len(problems)} issues</p></header>
<main>{''.join(cards)}</main>
<footer>Priority = Reach (unique users) + Severity + Trend + Business impact. Triggers are correlations, not confirmed root causes.</footer>
</body></html>"""
