@echo off
REM Works even when phones are on a different network (mobile data). Needs cloudflared:
REM   winget install --id Cloudflare.cloudflared      (or put cloudflared.exe in this folder)
cd /d "%~dp0"
pip install -q -r requirements.txt
python run_all.py --public
pause
