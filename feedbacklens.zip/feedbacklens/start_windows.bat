@echo off
cd /d "%~dp0"
pip install -q -r requirements.txt
netsh advfirewall firewall show rule name="FeedbackLens" >nul 2>&1 || call allow_firewall_windows.bat
python run_all.py
pause
