"""💰 Impact Forecast tab — predicted users lost and revenue at risk, with the evidence behind every number."""
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
import predict as R
from theme import BERRY, GRAY, INK, SERIES

REQUIRED = "user_id, tenure_days, orders_90d, avg_order_value, churned (1 = left, 0 = stayed, blank = not known yet)"


def _pct(x):
    return "–" if pd.isna(x) else f"{x:.0%}"


def render(df, problems, res):
    st.subheader("💰 Impact Forecast — which issues will cost us users and revenue?")
    st.caption("Predictions come from a churn model trained on past customers whose outcome is known, a forecast "
               "of how many new users each issue will hit, and a *what-if-fixed* comparison. Every number below "
               "shows its evidence.")
    if res is None:
        st.info("To predict churn and revenue, FeedbackLens needs **customer activity data** with these columns:  \n"
                f"`{REQUIRED}`  \nIn live mode this comes from the database; for an uploaded feedback CSV, also "
                "upload a customer CSV in the sidebar.")
        st.download_button("⬇ Customer data template (CSV)",
                           "user_id,tenure_days,orders_90d,avg_order_value,churned\nU00001,351,8,284,\nU00002,448,1,414,0\n",
                           "customer_template.csv")
        return
    if "error" in res:
        st.warning(f"Impact Forecast unavailable: {res['error']}")
        return
    b, imp, ser, ov = res["bundle"], res["impact"], res["series"], res["overall"]
    best = b["scores"][b["chosen"]]

    k = st.columns(5)
    k[0].metric("Outcome still open", f"{ov['at_risk']:,}", help="Complained recently; we don't know yet if they'll stay")
    k[1].metric("Likely to leave", f"{ov['expected_leavers']:.0f}", help="Sum of each customer's predicted chance of leaving")
    k[2].metric("Due to issues", f"{ov['caused_by_issues']:.0f}",
                help="Extra leavers caused by the detected issues (what-if-fixed comparison), no double counting")
    k[3].metric("Revenue at risk/mo", R.short(ov["revenue_month"]), help="Monthly spend of customers expected to leave because of issues")
    k[4].metric("Model AUC", f"{best['test_auc']:.2f}", help="0.5 = coin flip, 1.0 = perfect. Measured on customers the model never saw.")

    # ---------------- ranking
    top = imp.head(10).iloc[::-1]
    fig = go.Figure(go.Bar(
        x=top.revenue_month, y=top.title, orientation="h", marker_color=BERRY,
        error_x=dict(type="data", symmetric=False, array=top.revenue_hi - top.revenue_month,
                     arrayminus=top.revenue_month - top.revenue_lo, color=INK, thickness=1.2),
        customdata=np.stack([top.users_lost_30d, top.users_lost_lo, top.users_lost_hi], axis=1),
        hovertemplate="<b>%{y}</b><br>Revenue at risk: ₹%{x:,.0f}/month<br>Users likely lost: %{customdata[0]:.0f} "
                      "(%{customdata[1]:.0f}–%{customdata[2]:.0f})<extra></extra>"))
    fig.update_layout(height=420, margin=dict(l=0, r=10, t=30, b=0), title="Monthly revenue at risk per issue (bar = best estimate, line = likely range)",
                      xaxis_title="₹ per month")
    st.plotly_chart(fig, width="stretch")

    tbl = pd.DataFrame({
        "Issue": imp.title, "Users affected": imp.affected,
        "Already left (actual)": [f"{a} of {n} ({_pct(a / n) if n else '–'})" for a, n in zip(imp.already_lost, imp.outcome_known)],
        "Still at risk": imp.at_risk_now,
        "Chance of leaving: now → if fixed": [f"{_pct(a)} → {_pct(b_)}" for a, b_ in zip(imp.avg_p_churn, imp.avg_p_if_fixed)],
        "New users hit (next 30 days)": [f"{m:.0f} ({lo:.0f}–{hi:.0f})" for m, lo, hi in zip(imp.new_users_30d, imp.new_users_lo, imp.new_users_hi)],
        "Users likely lost (30 days)": [f"{m:.0f} ({lo:.0f}–{hi:.0f})" for m, lo, hi in zip(imp.users_lost_30d, imp.users_lost_lo, imp.users_lost_hi)],
        "Revenue at risk / month": [f"{R.inr(m)} ({R.inr(lo)}–{R.inr(hi)})" for m, lo, hi in zip(imp.revenue_month, imp.revenue_lo, imp.revenue_hi)],
        "Revenue at risk / 12 months": imp.revenue_12m.map(R.inr)})
    st.dataframe(tbl, hide_index=True, width="stretch", height=320)
    st.caption("Ranges are 80% likely ranges. A customer can be affected by several issues, so per-issue rows are not added up; "
               "the totals at the top are computed without double counting.")

    # ---------------- evidence for one issue
    st.divider()
    sel = st.selectbox("🔍 Show the evidence for", imp.title, key="imp_sel")
    f = imp[imp.title == sel].iloc[0]
    prob = problems[problems.issue_id == f.issue_id].iloc[0]
    s = ser[f.issue_id]; m = s["meta"]
    a, c = st.columns(2, gap="large")
    with a:
        st.markdown("**① Proof from history — did affected customers actually leave?**")
        base = b["baseline_rate"]
        ev = pd.DataFrame({"group": ["Customers with no complaints", "Customers who hit this issue"],
                           "rate": [base, f.observed_churn], "lo": [np.nan, f.churn_ci_lo], "hi": [np.nan, f.churn_ci_hi],
                           "n": [b["baseline_n"], f.outcome_known]})
        fig = go.Figure(go.Bar(x=ev.group, y=ev.rate, marker_color=[GRAY, BERRY], text=[_pct(v) for v in ev.rate],
                               textposition="inside", insidetextanchor="start", error_y=dict(type="data", symmetric=False, array=(ev.hi - ev.rate).fillna(0),
                                                                    arrayminus=(ev.rate - ev.lo).fillna(0), color=INK)))
        fig.update_layout(height=280, margin=dict(l=0, r=0, t=10, b=0), yaxis_tickformat=".0%", yaxis_title="Share who left",
                          yaxis_range=[0, max(0.1, float(np.nanmax([f.churn_ci_hi or 0, base])) * 1.3)])
        st.plotly_chart(fig, width="stretch")
        if f.outcome_known:
            ratio = f.observed_churn / base if base else np.nan
            st.caption(f"Actual history: **{f.already_lost} of {f.outcome_known}** affected customers with a known outcome left "
                       f"({_pct(f.observed_churn)}, 95% range {_pct(f.churn_ci_lo)}–{_pct(f.churn_ci_hi)}) vs "
                       f"**{_pct(base)}** of {b['baseline_n']:,} customers with no complaints — "
                       f"**{ratio:.1f}× more likely to leave**.")
        else:
            st.caption("No affected customer has a known outcome yet — prediction relies on the model only.")
    with c:
        st.markdown("**② Forecast — how many NEW users will hit this issue?**")
        end = s["end"]; H = len(s["history"])
        hist_x = [end - pd.Timedelta(days=7 * (H - 1 - i)) for i in range(H)]
        fx = [end + pd.Timedelta(days=7 * (j + 1)) for j in range(len(s["forecast"]))]
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=fx + fx[::-1], y=list(s["hi"]) + list(s["lo"])[::-1], fill="toself",
                                 fillcolor="rgba(252,108,38,0.18)", line=dict(width=0), mode="lines", name="80% range", hoverinfo="skip"))
        fig.add_trace(go.Scatter(x=hist_x, y=s["history"], mode="lines+markers", line=dict(color=INK, width=2), name="Actual (new users / week)"))
        fig.add_trace(go.Scatter(x=[hist_x[-1]] + fx, y=[s["history"][-1]] + list(s["forecast"]), mode="lines+markers",
                                 line=dict(color=BERRY, width=2, dash="dash"), name="Forecast"))
        fig.update_layout(height=280, margin=dict(l=0, r=0, t=10, b=0), yaxis_title="New users per week",
                          legend=dict(orientation="h", y=-0.25), hovermode="x unified")
        st.plotly_chart(fig, width="stretch")
        if m["mae"] is not None:
            better = (1 - m["mae"] / m["naive_mae"]) if m["naive_mae"] else 0
            st.caption(f"Method chosen by back-testing: **{m['method']}**. On past weeks it was off by **±{m['mae']} users/week** "
                       f"(simple 'same as last week' guess: ±{m['naive_mae']})" + (f" — **{better:.0%} more accurate**." if better > 0.005 else "."))
    d1, d2 = st.columns(2, gap="large")
    with d1:
        st.markdown("**③ What if we fix it?**")
        x = st.columns(3)
        x[0].metric("Chance of leaving now", _pct(f.avg_p_churn))
        x[1].metric("If fixed", _pct(f.avg_p_if_fixed), delta=f"-{(f.avg_p_churn - f.avg_p_if_fixed) * 100:.0f} pts" if pd.notna(f.avg_p_churn) else None,
                    delta_color="inverse")
        x[2].metric("Saved / month", R.short(f.revenue_month))
        st.caption(f"Each at-risk customer is re-scored with this issue's complaints removed (everything else unchanged). "
                   f"Fixing it keeps ≈**{f.users_lost_30d:.0f}** customers (likely {f.users_lost_lo:.0f}–{f.users_lost_hi:.0f}) "
                   f"≈ **{R.inr(f.revenue_12m)}** over 12 months.")
    with d2:
        st.markdown("**④ Customers most likely to leave (trace it back)**")
        st.dataframe(R.top_risk_customers(df, prob, b, 8), hide_index=True, width="stretch", height=250)

    with st.expander("🧠 How the prediction works (model card)"):
        sc = pd.DataFrame(b["scores"]).T.reset_index().rename(columns={"index": "Algorithm", "cv_auc": "Cross-validated AUC",
                                                                         "test_auc": "Test AUC (unseen customers)", "brier": "Brier score (lower = better)"})
        st.markdown(f"**Winner: {b['chosen']}** — trained on **{b['n_train']:,}** past customers with a known outcome; "
                    f"predicting **{b['n_unknown']:,}** customers whose outcome is still open.")
        st.dataframe(sc, hide_index=True, width="stretch")
        e1, e2 = st.columns(2)
        with e1:
            cal = b["calibration"]
            fig = go.Figure([go.Bar(name="Predicted", x=[f"Group {i+1}" for i in cal.index], y=cal.predicted, marker_color=GRAY),
                             go.Bar(name="Actually left", x=[f"Group {i+1}" for i in cal.index], y=cal.actual, marker_color=BERRY)])
            fig.update_layout(barmode="group", height=260, margin=dict(l=0, r=0, t=30, b=0), yaxis_tickformat=".0%",
                              title="Calibration: predicted vs actual (test customers, low → high risk)", legend=dict(orientation="h", y=-0.2))
            st.plotly_chart(fig, width="stretch")
        with e2:
            dr = b["drivers"].iloc[::-1]
            fig = go.Figure(go.Bar(x=dr.importance, y=dr.driver, orientation="h", marker_color=BERRY))
            fig.update_layout(height=260, margin=dict(l=0, r=0, t=30, b=0), title="What drives leaving (drop in AUC if removed)")
            st.plotly_chart(fig, width="stretch")
        st.caption("Limits: the model learns from history, so it shows strong association plus a what-if estimate — not a "
                   "controlled experiment. Revenue = expected leavers × their own monthly spend (orders/3 × average order value). "
                   "The demo uses generated customer data; connect your orders/CRM table for real numbers.")
