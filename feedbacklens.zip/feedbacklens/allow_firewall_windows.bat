@echo off
REM One-time fix: lets phones / other laptops reach FeedbackLens through Windows Firewall.
net session >nul 2>&1
if %errorlevel% neq 0 (
  echo Asking for administrator permission... click YES.
  powershell -Command "Start-Process '%~f0' -Verb RunAs"
  exit /b
)
echo Removing Windows "block" rules for Python (created when the firewall pop-up was cancelled)...
powershell -NoProfile -Command "Get-NetFirewallRule -Direction Inbound -Action Block -ErrorAction SilentlyContinue | Where-Object { ($_ | Get-NetFirewallApplicationFilter).Program -like '*python*' } | Remove-NetFirewallRule"
netsh advfirewall firewall delete rule name="FeedbackLens" >nul 2>&1
netsh advfirewall firewall add rule name="FeedbackLens" dir=in action=allow protocol=TCP localport=8000,8501,8502,8503 profile=any
echo.
echo Done! Now start FeedbackLens again (start_windows.bat).
pause
