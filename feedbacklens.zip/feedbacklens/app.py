"""FeedbackLens dashboard — run with:  streamlit run app.py"""
import io
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
import pipeline as P
import db
import network as NET

st.set_page_config(page_title="FeedbackLens", page_icon="🔎", layout="wide")
import theme  # noqa: E402
theme.apply(st, show_version=True)
import exports  # noqa: E402
from theme import BERRY, GRAY, SERIES  # Deep Berry + Vanilla Cloud look (also sets the chart template)
import report
C = dict(zip(["reach", "severity", "trend", "business"], SERIES))
BLUE = BERRY  # main single-series colour


# ------------------------------------------------------------------ data loading
SEV_LABEL = {0: "None (praise)", 1: "Low", 2: "Medium", 3: "High", 4: "Critical"}
db.init_db()


def load_csv(csv_bytes):
    raw = pd.read_csv(io.BytesIO(csv_bytes), dtype={"rating": object})
    raw.columns = [c.strip().lower() for c in raw.columns]
    if "text" not in raw:  # accept common alternatives
        alt = next((c for c in raw.columns if c in ("comment", "feedback", "feedback_text", "review", "message", "content")), None)
        if alt is None:
            raise ValueError("CSV needs a 'text' column (or comment/feedback/review/message).")
        raw = raw.rename(columns={alt: "text"})
    for col, default in [("user_id", None), ("timestamp", pd.Timestamp.now().isoformat()), ("rating", ""),
                         ("source", "upload"), ("platform", "unknown"), ("feedback_id", None), ("app_version", "")]:
        if col not in raw:
            raw[col] = [f"row{i}" for i in range(len(raw))] if default is None else default
    return raw


@st.cache_data(show_spinner="Understanding & clustering feedback…")
def analyse(source, app_id, csv_bytes, version, threshold):
    """version = (feedback count, review count) snapshot -> re-runs only when you press Process (or in realtime mode)."""
    raw = load_csv(csv_bytes) if source == "csv" else db.get_feedback(app_id)
    if raw.text.fillna("").str.len().gt(0).sum() < 20:
        raise ValueError("Not enough text feedback yet (need at least 20). Submit some via AppBazaar or a FeedbackForm.")
    df = P.apply_reviews(P.understand(raw), db.get_reviews())
    df, X = P.cluster(df, threshold=threshold)
    return df, P.label_issues(df, X)


st.sidebar.title("🔎 FeedbackLens")
st.sidebar.caption("Messy feedback → prioritised, traceable product decisions")
src = st.sidebar.radio("Data source", ["📡 Live database", "📁 Upload CSV"], horizontal=True)
csv_bytes, app_id, cust_bytes = None, None, None
if src.startswith("📁"):
    up = st.sidebar.file_uploader("Upload feedback CSV", type="csv",
                                  help="Columns: text (required), user_id, timestamp, rating, source, platform")
    csv_bytes = up.getvalue() if up else open("data/sample_feedback.csv", "rb").read()
    st.sidebar.caption("Using: " + (up.name if up else "demo dataset (5k records)"))
    cup = st.sidebar.file_uploader("Customer activity CSV (for 💰 Impact Forecast)", type="csv",
                                   help="user_id, tenure_days, orders_90d, avg_order_value, churned (1/0/blank)")
    cust_bytes = cup.getvalue() if cup else (None if up else open("data/customers.csv", "rb").read())
    current = (len(csv_bytes), len(db.get_reviews()))
else:
    apps = {a["app_id"]: a for a in db.list_apps()}
    app_id = st.sidebar.selectbox("Product", list(apps), format_func=lambda k: f"{apps[k]['icon']} {apps[k]['name']}")
    current = (db.count_feedback(app_id), len(db.get_reviews()))
source = "csv" if csv_bytes else "db"
realtime = st.sidebar.toggle("⚡ Realtime mode", False, help="Re-analyse automatically on every new feedback / review. "
                             "Off = batch mode: press Process to pull in new data.")
snaps = st.session_state.setdefault("snap", {})
key = (source, app_id)
if realtime or key not in snaps:
    snaps[key] = current
new_fb, new_rv = current[0] - snaps[key][0], current[1] - snaps[key][1]


@st.fragment(run_every="5s")
def live_watch(snap):
    """Checks the shared database every 5 s — picks up reviews sent from phones / other laptops."""
    cur = (db.count_feedback(app_id), len(db.get_reviews()))
    nf, nr = cur[0] - snap[0], cur[1] - snap[1]
    seen = st.session_state.get("seen_count", cur[0])
    if cur[0] > seen:
        st.toast(f"📩 {cur[0] - seen} new feedback just arrived")
    st.session_state.seen_count = cur[0]
    if realtime and (nf or nr):
        st.rerun(scope="app")
    if nf or nr:
        st.warning(f"🆕 {nf} new feedback · {nr} new human decisions waiting — press Process")
    else:
        st.caption("🟢 Live · checking for new feedback every 5 s")


with st.sidebar:
    if source == "db":
        live_watch(snaps[key])
    elif new_rv:
        st.warning(f"🆕 {new_rv} new human decisions waiting")
process_clicked = st.sidebar.button("⚙️ Process new feedback", type="primary" if (new_fb or new_rv) else "secondary",
                                    width="stretch")
if process_clicked:
    snaps[key] = current

if source == "db":
    with st.sidebar.expander("📱 Open on phones / other laptops"):
        ab = NET.url(8502)
        st.markdown("**On this laptop:** [localhost:8502](http://localhost:8502)")
        st.image(NET.qr_png(ab), caption="Scan → AppBazaar", width=150)
        st.code(ab, language=None)
        others = [i for i in NET.all_ips() if i not in ab]
        if others:
            st.caption("Other addresses to try: " + ", ".join(f"http://{i}:8502" for i in others))
        st.caption("Phone must be on the same Wi-Fi (college Wi-Fi often blocks this → use your phone hotspot), "
                   "or start with start_public_windows.bat.")

with st.sidebar.expander("⚖️ Priority weights (transparent scoring)", expanded=False):
    w = {"reach": st.slider("Reach (unique users)", 0.0, 1.0, P.DEFAULT_WEIGHTS["reach"], 0.05),
         "severity": st.slider("Severity", 0.0, 1.0, P.DEFAULT_WEIGHTS["severity"], 0.05),
         "trend": st.slider("Trend (growth)", 0.0, 1.0, P.DEFAULT_WEIGHTS["trend"], 0.05),
         "business": st.slider("Business impact", 0.0, 1.0, P.DEFAULT_WEIGHTS["business"], 0.05)}
granularity = st.sidebar.slider("Issue granularity", 0.80, 1.00, 0.93, 0.01,
                                help="Lower = more, finer-grained issues. Higher = fewer, broader themes.")
with st.sidebar.expander("🚀 Release dates", expanded=False):
    rel_txt = st.text_area("version=YYYY-MM-DD, one per line",
                           "\n".join(f"{k}={v}" for k, v in P.RELEASES.items()))
releases = dict(l.split("=", 1) for l in rel_txt.splitlines() if "=" in l)

try:
    df, info = analyse(source, app_id, csv_bytes, snaps[key], granularity)
except Exception as e:
    st.error(f"Could not analyse: {e}")
    df = None
if df is not None:
    issues = P.build_issues(df, info, w, releases)
    problems = issues[issues.kind == "problem"].reset_index(drop=True)
if process_clicked and df is not None:
    with st.status("Processing feedback…", expanded=True, state="complete") as s:
        st.write(f"✓ {len(df):,} feedback records loaded ({new_fb} new)")
        st.write(f"✓ {int((df.canon != '').sum()):,} analysed · {int(df.needs_review.sum())} sent to human review")
        st.write(f"✓ {new_rv} human decisions applied ({int(df.excluded.sum())} rejected items excluded in total)")
        st.write(f"✓ {len(problems)} issues detected · {int((problems.growth >= 1.5).sum())} emerging")
        st.write("✓ Priority scores updated")


@st.fragment(run_every="5s")
def latest_feed():
    st.subheader("🟢 Latest incoming feedback (live, all devices)")
    f = db.get_feedback(app_id, 8)
    st.dataframe(pd.DataFrame({"Received": f.received_at.map(exports._date), "Source": f.source.map(lambda x: exports.SOURCE.get(x, x)),
                               "Rating": f.rating.map(exports._stars), "Message": f.text, "Device": f.platform.fillna("-"),
                               "Feedback ID": f.feedback_id}), hide_index=True, width="stretch")


def arrow(g):
    return "🔺" if g >= 1.5 else "↗" if g >= 1.15 else "→" if g >= 0.85 else "↘"


# ------------------------------------------------------------------ tabs
t1, t2, t8, t3, t4, t5, t6, t7 = st.tabs(["📊 Overview", "🔥 Priorities", "💰 Impact Forecast", "📈 Trends",
                                          "🔍 Evidence Explorer", "🧠 Decision Assistant", "👨‍💼 Human Review", "📝 Feedback Forms"])
import hitl_forms  # noqa: E402  (tabs 6-7 live in their own file to keep this one readable)
with t7:
    hitl_forms.forms_tab()
if df is None or problems.empty:
    with t6:
        st.info("Human review needs analysed feedback first.")
    st.stop()
with t6:
    hitl_forms.review_tab(df, issues)


@st.cache_data(show_spinner="Training churn model & forecasting impact…")
def impact(cache_key, _df, _issues, _cust_bytes):
    """cache_key changes only when the analysed data changes."""
    import predict as R
    try:
        cust = pd.read_csv(io.BytesIO(_cust_bytes)) if _cust_bytes is not None else db.get_customers()
        miss = set(R.CUSTOMER_COLS) - set(cust.columns)
        if miss or cust.empty:
            return None if cust.empty else {"error": f"customer file is missing columns: {', '.join(sorted(miss))}"}
        cust["user_id"] = cust.user_id.astype(str)
        bundle = R.train(_df[~_df.excluded], cust[R.CUSTOMER_COLS])
        imp, series = R.issue_impact(_df, _issues, bundle)
        return {"bundle": bundle, "impact": imp, "series": series, "overall": R.overall(_df, _issues, bundle)}
    except Exception as e:  # never break the dashboard
        return {"error": str(e)}


use_cust = source == "db" or cust_bytes is not None
imp_res = impact((source, app_id, snaps[key], granularity, len(cust_bytes or b"")), df, issues, cust_bytes) if use_cust else None
imp_df = imp_res["impact"] if imp_res and "impact" in imp_res else None
import impact_tab  # noqa: E402
with t8:
    impact_tab.render(df, problems, imp_res)

with t1:
    emerging = problems[problems.growth >= 1.5]
    k = st.columns(5)
    k[0].metric("Feedback analysed", f"{len(df):,}")
    k[1].metric("Unique users", f"{df.user_id.nunique():,}")
    k[2].metric("Issues detected", len(problems))
    k[3].metric("Emerging issues", len(emerging), help="Volume ≥1.5× the previous 8 weeks")
    k[4].metric("High-impact issues", int((problems.priority >= 60).sum()), help="Priority score ≥ 60")

    top = problems.head(5).iloc[0]
    st.error(f"**🚨 Top problem: {top.title}** — {top.unique_users:,} users affected, "
             f"{top.growth}× growth{f', began after {top.possible_trigger}' if top.possible_trigger else ''}.")

    a, b = st.columns([3, 2])
    with a:
        st.subheader("Top 10 issues by priority")
        t10 = problems.head(10).iloc[::-1]
        fig = px.bar(t10, x="priority", y="title", orientation="h", color_discrete_sequence=[BLUE],
                     hover_data={"unique_users": True, "records": True, "growth": True, "title": False},
                     labels={"priority": "Priority score (0–100)", "title": ""})
        fig.update_layout(height=420, margin=dict(l=0, r=10, t=10, b=0))
        st.plotly_chart(fig, width="stretch")
    with b:
        st.subheader("Where problems live")
        area = problems.groupby("area").agg(users=("unique_users", "sum")).sort_values("users").reset_index()
        fig = px.bar(area, x="users", y="area", orientation="h", color_discrete_sequence=[BLUE],
                     labels={"users": "Affected users", "area": ""})
        fig.update_layout(height=250, margin=dict(l=0, r=10, t=10, b=0))
        st.plotly_chart(fig, width="stretch")
        s = df.sentiment.value_counts()
        st.caption("Sentiment is context, not the answer: " +
                   " · ".join(f"{k} {v/len(df):.0%}" for k, v in s.items()))
        st.caption(f"Sources: " + " · ".join(f"{k} {v:,}" for k, v in df.source.value_counts().items()))

    if source == "db":
        latest_feed()

with t2:
    st.subheader("Prioritised issues")
    st.caption("Score = weighted Reach + Severity + Trend + Business impact. Reach counts **unique people**, "
               "so one person posting 40 times counts once.")
    tbl = problems.assign(trend=problems.growth.map(lambda g: f"{arrow(g)} {g}×"))[
        ["priority_rank", "title", "priority", "unique_users", "records", "severity", "trend", "avg_rating",
         "top_segment", "possible_trigger", "confidence"]]
    st.dataframe(tbl, hide_index=True, width="stretch", height=360,
                 column_config={"priority": st.column_config.ProgressColumn("priority", min_value=0, max_value=100, format="%.1f"),
                                "priority_rank": "#", "severity": st.column_config.NumberColumn("severity (0–4)")})

    st.subheader("Why is each issue ranked here?")
    br = []
    for _, r in problems.head(10).iterrows():
        for name, pts, _ in P.explain(r, w):
            br.append({"issue": f"#{r.priority_rank} {r.title}", "component": name, "points": pts})
    br = pd.DataFrame(br)
    fig = px.bar(br, x="points", y="issue", color="component", orientation="h",
                 color_discrete_map={"Reach": C["reach"], "Severity": C["severity"], "Trend": C["trend"], "Business impact": C["business"]},
                 category_orders={"issue": [f"#{r.priority_rank} {r.title}" for _, r in problems.head(10).iterrows()]},
                 labels={"points": "Points contributed to priority score", "issue": ""})
    fig.update_traces(marker_line_color="white", marker_line_width=2)
    fig.update_layout(height=420, margin=dict(l=0, r=10, t=10, b=0), legend=dict(orientation="h", y=1.08, title=""))
    st.plotly_chart(fig, width="stretch")

    st.subheader("📢 Loudest complainer vs. real problem")
    loud = (df[df.sentiment != "positive"].assign(anger=lambda d: d.shouting.astype(int) + d.text.str.count("!|😡"))
            .groupby("user_id").agg(messages=("text", "size"), anger=("anger", "sum"), issue_id=("issue_id", lambda s: s.mode()[0]))
            .sort_values("messages", ascending=False).head(5).reset_index())
    loud = loud.merge(issues[["issue_id", "title", "priority_rank", "unique_users"]], on="issue_id", how="left")
    c1, c2 = st.columns(2)
    with c1:
        st.markdown("**Loudest users** (what a busy team notices)")
        st.dataframe(loud[["user_id", "messages", "anger", "title", "priority_rank"]].rename(
            columns={"title": "their issue", "priority_rank": "real rank"}), hide_index=True, width="stretch")
    with c2:
        L = loud.iloc[0]; li = issues[issues.issue_id == L.issue_id].iloc[0]; T = problems.iloc[0]
        cmp = pd.DataFrame({"issue": [li.title, T.title] * 2,
                            "measure": ["Messages"] * 2 + ["Unique users"] * 2,
                            "value": [li.records, T.records, li.unique_users, T.unique_users]})
        fig = px.bar(cmp, x="measure", y="value", color="issue", barmode="group", log_y=True,
                     color_discrete_sequence=[GRAY, BLUE], labels={"value": "Count (log scale)", "measure": ""})
        fig.update_layout(height=260, margin=dict(l=0, r=0, t=10, b=0), legend=dict(orientation="h", y=-0.2, title=""))
        st.plotly_chart(fig, width="stretch")
        st.info(f"User **{L.user_id}** sent **{L.messages}** messages, but their issue reaches "
                f"**{li.unique_users}** user(s) → rank **#{li.priority_rank}**. The top issue quietly affects "
                f"**{T.unique_users:,}** different users.")

with t3:
    st.subheader("Complaint volume over time")
    pick = st.multiselect("Issues", problems.title.tolist(), default=problems.title.head(4).tolist())
    ids = problems.set_index("title").loc[pick, "issue_id"].tolist() if pick else []
    ts = (df[df.issue_id.isin(ids)].merge(problems[["issue_id", "title"]], on="issue_id")
          .set_index("timestamp").groupby("title").resample("W")["text"].size().reset_index(name="complaints"))
    if len(ts):
        order = {t: i for i, t in enumerate(problems.title)}  # colour follows the issue, not its position in the pick
        pal = SERIES
        fig = px.line(ts, x="timestamp", y="complaints", color="title", markers=True,
                      color_discrete_map={t: pal[order[t] % len(pal)] for t in pick},
                      labels={"timestamp": "Week", "complaints": "Complaints per week", "title": ""})
        for v, d in releases.items():
            fig.add_vline(x=pd.Timestamp(d).timestamp() * 1000, line_dash="dot", line_color=GRAY,
                          annotation_text=f"release {v}", annotation_position="top left")
        fig.update_layout(height=420, hovermode="x unified", legend=dict(orientation="h", y=-0.3))
        st.plotly_chart(fig, width="stretch")
    st.subheader("🚨 Emerging issues")
    for _, r in problems[problems.spike_week.notna()].head(6).iterrows():
        st.warning(f"**{r.title}** — spike from week of {r.spike_week:%d %b}; now {r.recent_per_day}/day vs "
                   f"{r.base_per_day}/day before ({r.growth}×)" +
                   (f". Possible regression after **{r.possible_trigger}**." if r.possible_trigger else "."))

with t4:
    sel = st.selectbox("Pick an issue to trace", problems.title, key="ev")
    r = problems[problems.title == sel].iloc[0]
    members = df.loc[r.member_ids]
    st.markdown(f"### #{r.priority_rank} {r.title}")
    st.caption(f"Keywords: {r.keywords} · cluster cohesion {r.cohesion} · confidence {r.confidence}")
    chain = [f"**{r.records:,}** feedback records", f"**{r.unique_users:,}** unique users"
             + (f" ({r.repeats} repeat messages from same users)" if r.repeats else "")]
    crit = int(r.pct_critical * 100)
    if crit: chain.append(f"**{crit}%** involve money loss / critical failure")
    if r.top_segment: chain.append(f"**{int(r.segment_share*100)}%** specifically mention **{r.top_segment}**")
    chain.append(f"Volume **{r.growth}×** the previous 8 weeks")
    if r.avg_rating == r.avg_rating and r.avg_rating is not None: chain.append(f"Average rating **{r.avg_rating}/5**")
    a, b = st.columns([2, 3])
    with a:
        st.markdown("**Why? (trace the decision back to data)**")
        st.markdown("\n\n↓\n\n".join(chain))
    with b:
        st.markdown("**Score breakdown**")
        for name, pts, desc in P.explain(r, w):
            st.markdown(f"- **{name}: +{pts}** — {desc}")
        st.markdown(f"**= {r.priority} / 100**")
        st.markdown("**Most representative evidence**")
        for i in r.evidence_ids[:5]:
            m = df.loc[i]
            st.markdown(f"> “{m.text[:160]}”  \n<sub>{m.source} · {m.user_id} · {m.timestamp:%d %b %Y} · "
                        f"{'★'*int(m.rating) if m.rating == m.rating else 'no rating'}</sub>", unsafe_allow_html=True)
    st.markdown("**All source records**")
    q = st.text_input("Filter text", "")
    show = members[members.text.str.contains(q, case=False)] if q else members
    st.dataframe(show[["feedback_id", "timestamp", "source", "user_id", "rating", "text", "sentiment", "severity",
                       "segment", "platform", "app_version", "ai_confidence", "verified", "is_repeat"]].sort_values("timestamp", ascending=False),
                 hide_index=True, width="stretch", height=300)
    st.download_button("⬇ Download evidence (Excel)", exports.to_excel({"Evidence": exports.evidence_table(show)}),
                       f"Evidence - {r.title.split(': ', 1)[-1][:40]}.xlsx", mime=exports.XLSX)

with t5:
    sel = st.selectbox("Issue", problems.title, key="da")
    r = problems[problems.title == sel].iloc[0]
    ins = P.insight(r)
    st.markdown(f"## 🧠 {ins['headline']}")
    c = st.columns(4)
    c[0].metric("Priority", f"{r.priority}", f"rank #{r.priority_rank}", delta_color="off")
    c[1].metric("Affected users", f"{r.unique_users:,}")
    c[2].metric("Trend", f"{r.growth}×", arrow(r.growth), delta_color="off")
    c[3].metric("Confidence", f"{ins['confidence']:.2f}")
    st.markdown(f"**What we know:** {ins['what_we_know']}")
    st.markdown(f"**Possible trigger:** {ins['possible_trigger']}")
    st.markdown(f"**Recommended investigation:** {ins['recommended_investigation']}")
    if st.button("✨ Deeper analysis"):
        out = P.llm_insight(r, [df.at[i, "text"] for i in r.evidence_ids])
        st.info(out or "Deeper analysis is not switched on for this laptop yet (it needs an AI key set up).")

    st.divider()
    st.download_button("⬇ Download top-10 decision report", report.build(problems, df, imp=imp_df),
                       "FeedbackLens_Decision_Report.html", mime="text/html",
                       help="Opens in any browser. To get a PDF: open it → Print → Save as PDF.")
    st.download_button("⬇ Download all issues (Excel)", exports.to_excel({"Prioritised issues": exports.issues_table(problems, df, imp_df)}),
                       "FeedbackLens - Prioritised Issues.xlsx", mime=exports.XLSX)
