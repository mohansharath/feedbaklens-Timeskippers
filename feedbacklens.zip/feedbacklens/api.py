"""FeedbackLens API — the single contract every feedback source talks to.
Run:  uvicorn api:app --port 8000     Docs: http://localhost:8000/docs

ANALYSIS_MODE=realtime  -> re-analyse in the background after every new feedback
ANALYSIS_MODE=batch     -> re-analyse after every BATCH_SIZE new records (default 50)
"""
import os
from typing import Optional
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import db, pipeline as P

MODE = os.getenv("ANALYSIS_MODE", "batch")
BATCH_SIZE = int(os.getenv("BATCH_SIZE", "50"))
app = FastAPI(title="FeedbackLens API", version="1.0",
              description="Common feedback contract for AppBazaar, FeedbackForm, CSV imports and future sources.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
db.init_db()
_cache = {}  # app_id -> {"count": n, "df": ..., "issues": ...}


class FeedbackIn(BaseModel):
    app_id: str = Field(examples=["shopflow"])
    feedback_text: str = Field("", examples=["UPI payment failed again"])
    rating: Optional[float] = Field(None, ge=1, le=5)
    source: str = Field("api", examples=["appbazaar", "feedbackform", "csv"])
    user_id: Optional[str] = None
    product_area: Optional[str] = None
    form_id: Optional[str] = None
    platform: Optional[str] = None
    app_version: Optional[str] = None
    timestamp: Optional[str] = None


class FormIn(BaseModel):
    app_id: str
    title: str
    description: str = ""
    question: str = "How was your experience?"
    areas: list[str] = ["Payments", "Checkout", "Search", "Delivery", "UI & Design"]


def process(app_id="shopflow"):
    """Run the full pipeline on the current database (with human review decisions applied)."""
    raw = db.get_feedback(app_id)
    if raw.text.fillna("").str.len().gt(0).sum() < 20:
        _cache[app_id] = {"count": len(raw), "df": None, "issues": None}
        return {"feedback": len(raw), "issues": 0, "note": "not enough text feedback yet (need 20+)"}
    df, issues = P.run(raw, reviews=db.get_reviews())
    _cache[app_id] = {"count": len(raw), "df": df, "issues": issues}
    prob = issues[issues.kind == "problem"]
    return {"feedback": len(raw), "issues": len(prob), "emerging": int((prob.growth >= 1.5).sum()),
            "needs_human_review": int(df.needs_review.sum())}


def _issues(app_id):
    if app_id not in _cache:
        process(app_id)
    c = _cache[app_id]
    if c["issues"] is None:
        raise HTTPException(404, "Not enough feedback analysed for this app yet")
    return c


@app.post("/api/v1/feedback", status_code=201, tags=["feedback"])
def submit_feedback(f: FeedbackIn, bg: BackgroundTasks):
    if not db.get_app(f.app_id):
        raise HTTPException(404, f"Unknown app_id '{f.app_id}'")
    if not f.feedback_text.strip() and f.rating is None:
        raise HTTPException(422, "Send feedback_text or rating")
    fid = db.insert_feedback(f.model_dump())
    pending = db.count_feedback(f.app_id) - _cache.get(f.app_id, {}).get("count", 0)
    if MODE == "realtime" or pending >= BATCH_SIZE:
        bg.add_task(process, f.app_id)
    return {"feedback_id": fid, "status": "stored", "analysis_mode": MODE, "pending_analysis": pending}


@app.get("/api/v1/feedback", tags=["feedback"])
def list_feedback(app_id: Optional[str] = None, limit: int = 100):
    return db.get_feedback(app_id, limit).fillna("").to_dict("records")


@app.get("/api/v1/feedback/latest", tags=["feedback"])
def latest(app_id: Optional[str] = None):
    return db.get_feedback(app_id, 10).fillna("").to_dict("records")


@app.get("/api/v1/apps", tags=["apps"])
def apps():
    return db.list_apps()


@app.get("/api/v1/apps/{app_id}", tags=["apps"])
def app_detail(app_id: str):
    a = db.get_app(app_id)
    if not a:
        raise HTTPException(404, "App not found")
    return a


@app.post("/api/v1/forms", status_code=201, tags=["forms"])
def create_form(f: FormIn):
    return {"form_id": db.create_form(f.app_id, f.title, f.description, f.question, f.areas)}


@app.get("/api/v1/forms", tags=["forms"])
def forms():
    return db.list_forms()


@app.get("/api/v1/forms/{form_id}", tags=["forms"])
def form(form_id: str):
    f = db.get_form(form_id)
    if not f:
        raise HTTPException(404, "Form not found")
    return f


@app.post("/api/v1/analysis/process", tags=["analysis"])
def run_analysis(app_id: str = "shopflow"):
    return process(app_id)


@app.get("/api/v1/issues", tags=["analysis"])
def issues(app_id: str = "shopflow", limit: int = 20):
    iss = _issues(app_id)["issues"]
    iss = iss[iss.kind == "problem"].head(limit)
    cols = ["issue_id", "priority_rank", "title", "area", "priority", "unique_users", "records", "severity",
            "growth", "top_segment", "possible_trigger", "confidence"]
    return iss[cols].to_dict("records")


@app.get("/api/v1/issues/{issue_id}/evidence", tags=["analysis"])
def evidence(issue_id: int, app_id: str = "shopflow"):
    c = _issues(app_id); iss = c["issues"]
    row = iss[iss.issue_id == issue_id]
    if row.empty:
        raise HTTPException(404, "Issue not found")
    r = row.iloc[0]; df = c["df"]
    return {"issue": r.title, "priority": r.priority, "insight": {k: str(v) for k, v in P.insight(r).items()},
            "why": [{"component": n, "points": p, "detail": d} for n, p, d in P.explain(r)],
            "evidence": df.loc[r.evidence_ids, ["feedback_id", "source", "user_id", "rating", "text"]]
                          .fillna("").to_dict("records")}


@app.get("/api/v1/reviews/stats", tags=["human review"])
def review_stats():
    rv = db.get_reviews()
    n = len(rv)
    counts = rv.action.value_counts().to_dict() if n else {}
    return {"reviewed": n, **{k: counts.get(k, 0) for k in ("accepted", "edited", "rejected")}}


@app.get("/api/v1/impact", tags=["analysis"])
def impact(app_id: str = "shopflow", limit: int = 10):
    """Predicted users lost and revenue at risk per issue (churn model + forecast + what-if-fixed)."""
    import predict as R
    c = _issues(app_id)
    cust = db.get_customers()
    if cust.empty:
        raise HTTPException(404, "No customer activity data loaded")
    b = R.train(c["df"][~c["df"].excluded], cust)
    imp, _ = R.issue_impact(c["df"], c["issues"], b)
    cols = ["issue_id", "title", "affected", "already_lost", "at_risk_now", "users_lost_30d", "users_lost_lo",
            "users_lost_hi", "revenue_month", "revenue_lo", "revenue_hi", "revenue_12m"]
    return {"model": b["chosen"], "test_auc": b["scores"][b["chosen"]]["test_auc"],
            "overall": R.overall(c["df"], c["issues"], b), "issues": imp[cols].head(limit).round(2).to_dict("records")}
