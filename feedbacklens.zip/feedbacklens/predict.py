"""Impact Forecast: evidence-based prediction of users lost (churn) and revenue at risk per issue.

1. Churn model   — learns from PAST customers whose outcome is known (did they leave?), using their feedback
                   + activity. Two algorithms compete (Logistic Regression vs Gradient Boosting); the one with the
                   better cross-validated AUC wins. Tested on customers it never saw.
2. Forecast      — projects how many NEW users will hit each issue in the next 30 days. Four methods (damped Holt
                   trend, linear trend, 4-week average, last-week-repeated) compete on rolling back-tests of weeks we
                   already know; the most accurate one is used for each issue.
3. Attribution   — counterfactual: re-score each affected customer WITHOUT that issue's complaints.
                   The drop in churn probability = churn caused by the issue (not just correlated with the person).
4. Revenue       — expected lost customers × their own monthly spend (orders × average order value).
Required customer columns: user_id, tenure_days, orders_90d, avg_order_value, churned (1/0, blank = not known yet).
"""
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import brier_score_loss, roc_auc_score
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

HORIZON_DAYS = 30
CUSTOMER_COLS = ["user_id", "tenure_days", "orders_90d", "avg_order_value", "churned"]
CHURN_WORDS = r"uninstall|switch|never again|deleting|delete|moving to|cancel my|leaving"
NICE = {"n_feedback": "Number of feedback messages (log)", "n_negative": "Negative messages (log)", "min_rating": "Lowest rating given",
        "max_severity": "Worst problem severity", "money_issue": "Lost money (debited / charged twice)",
        "churn_words": "Said they'd uninstall / switch", "tenure_days": "Days as a customer",
        "orders_90d": "Orders in last 90 days", "avg_order_value": "Average order value"}


def nice(f):
    return NICE.get(f, f.replace("area_", "Experienced: ") if f.startswith("area_") else f)


# ------------------------------------------------------------------ features
def feedback_features(fb: pd.DataFrame) -> pd.DataFrame:
    if fb.empty:
        return pd.DataFrame()
    fb = fb.assign(neg=(fb.sentiment == "negative").astype(int), money=(fb.severity == 4).astype(int),
                   cw=fb.text.fillna("").str.lower().str.contains(CHURN_WORDS).astype(int))
    g = fb.groupby("user_id")
    f = pd.DataFrame({"n_feedback": g.size(), "n_negative": g.neg.sum(), "min_rating": g.rating.min(),
                      "max_severity": g.severity.max(), "money_issue": g.money.max(), "churn_words": g.cw.max()})
    f[["n_feedback", "n_negative"]] = np.log1p(f[["n_feedback", "n_negative"]].clip(upper=10))  # no wild extrapolation
    areas = pd.crosstab(fb.user_id, fb.area).clip(upper=1).add_prefix("area_")
    return f.join(areas)


def build_matrix(fb, customers):
    """One row per customer: activity + what they experienced. Customers with no feedback are the baseline."""
    c = customers.set_index("user_id")
    new = pd.Index(fb.user_id.unique()).difference(c.index)            # e.g. brand-new AppBazaar users
    if len(new):
        med = c[["tenure_days", "orders_90d", "avg_order_value"]].median()
        c = pd.concat([c, pd.DataFrame({**med.to_dict(), "churned": np.nan}, index=new)])
    X = c.join(feedback_features(fb), how="left")
    X["min_rating"] = X["min_rating"].fillna(4.0)                      # no rating given ≈ neutral-positive
    return X.fillna({k: 0 for k in X.columns if k not in ("churned",)})


# ------------------------------------------------------------------ churn model
def train(fb, customers):
    X = build_matrix(fb, customers)
    feats = [k for k in X.columns if k != "churned"]
    lab = X[X.churned.notna()]
    if len(lab) < 200 or lab.churned.nunique() < 2:
        raise ValueError("Need at least 200 customers with a known outcome (churned = 1/0) to train.")
    y = lab.churned.astype(int)
    Xtr, Xte, ytr, yte = train_test_split(lab[feats], y, test_size=0.25, stratify=y, random_state=0)
    cands = {"Logistic Regression": make_pipeline(StandardScaler(), LogisticRegression(max_iter=2000, C=0.5)),
             "Gradient Boosting": HistGradientBoostingClassifier(max_depth=3, learning_rate=0.06, max_iter=250,
                                                                l2_regularization=1.0, random_state=0)}
    cv = StratifiedKFold(5, shuffle=True, random_state=0)
    scores = {}
    for name, m in cands.items():
        cv_auc = cross_val_score(m, Xtr, ytr, cv=cv, scoring="roc_auc").mean()
        m.fit(Xtr, ytr); p = m.predict_proba(Xte)[:, 1]
        scores[name] = {"cv_auc": round(cv_auc, 3), "test_auc": round(roc_auc_score(yte, p), 3),
                        "brier": round(brier_score_loss(yte, p), 3)}
    best = max(scores, key=lambda k: scores[k]["cv_auc"])
    model = cands[best]
    p_te = model.predict_proba(Xte)[:, 1]
    calib = (pd.DataFrame({"p": p_te, "y": yte.values}).assign(bin=lambda d: pd.qcut(d.p, 5, labels=False, duplicates="drop"))
             .groupby("bin").agg(predicted=("p", "mean"), actual=("y", "mean"), customers=("y", "size")).reset_index(drop=True))
    imp = permutation_importance(model, Xte, yte, scoring="roc_auc", n_repeats=5, random_state=0)
    drivers = (pd.DataFrame({"feature": feats, "importance": imp.importances_mean})
               .sort_values("importance", ascending=False).head(8))
    drivers["driver"] = drivers.feature.map(nice)
    model.fit(lab[feats], y)                                           # final model uses all labelled history
    X["p_churn"] = model.predict_proba(X[feats])[:, 1]
    X["monthly_revenue"] = X.orders_90d / 3 * X.avg_order_value
    base = lab[lab.n_feedback == 0].churned
    return {"model": model, "features": feats, "X": X, "chosen": best, "scores": scores, "calibration": calib,
            "drivers": drivers, "n_train": len(lab), "n_unknown": int(X.churned.isna().sum()),
            "baseline_rate": float(base.mean()) if len(base) else float(y.mean()), "baseline_n": int(len(base))}


def _predict(bundle, fb_subset, users):
    """Churn probability for `users` computed from the given feedback subset (used for the counterfactual)."""
    X = bundle["X"].loc[users, ["tenure_days", "orders_90d", "avg_order_value", "churned"]]
    F = feedback_features(fb_subset[fb_subset.user_id.isin(users)])
    M = X.join(F, how="left").reindex(columns=bundle["features"] + ["churned"])
    M["min_rating"] = M["min_rating"].fillna(4.0)
    M = M.fillna({k: 0 for k in bundle["features"]})
    return pd.Series(bundle["model"].predict_proba(M[bundle["features"]])[:, 1], index=users)


# ------------------------------------------------------------------ forecast
def weekly_users(ts_users: pd.DataFrame, end, weeks=16):
    """NEW affected users per 7-day block ending at `end` (a user counts only the first time they hit the issue)."""
    first = ts_users.groupby("user_id").timestamp.min()
    first = first[first <= end]
    k = ((end - first).dt.days // 7)
    s = k[k < weeks].value_counts().reindex(range(weeks), fill_value=0)
    return s.values[::-1].astype(float)


def holt(y, h=4, phi=0.9):
    """Damped Holt linear trend, parameters chosen by one-step-ahead error. Returns forecast, 80% band."""
    best = None
    for a in (0.2, 0.35, 0.5, 0.7, 0.9):
        for b in (0.05, 0.1, 0.2, 0.3):
            l, t, err = y[0], (y[1] - y[0]) if len(y) > 1 else 0.0, []
            for x in y[1:]:
                f = l + phi * t; err.append(x - f)
                ln = a * x + (1 - a) * f; t = b * (ln - l) + (1 - b) * phi * t; l = ln
            sse = float(np.sum(np.square(err[2:]))) if len(err) > 2 else 0.0
            if best is None or sse < best[0]:
                best = (sse, l, t, np.std(err[2:]) if len(err) > 2 else 0.0)
    _, l, t, sd = best
    fc = np.array([max(0.0, l + sum(phi ** j for j in range(1, i + 1)) * t) for i in range(1, h + 1)])
    band = np.array([1.28 * sd * np.sqrt(i) for i in range(1, h + 1)])
    return fc, np.maximum(0, fc - band), fc + band


def _naive(y, h=4):
    return np.repeat(y[-1], h)


def _mean4(y, h=4):
    return np.repeat(y[-4:].mean(), h)


def _linear(y, h=4):
    t = np.arange(len(y[-8:])); a, b = np.polyfit(t, y[-8:], 1)
    return np.maximum(0, a * (t[-1] + np.arange(1, h + 1)) + b)


METHODS = {"Damped trend (Holt)": lambda y, h=4: holt(y, h)[0], "Last week repeated": _naive,
           "4-week average": _mean4, "Linear trend (8 weeks)": _linear}


def forecast(y, h=4, origins=3):
    """Methods compete on rolling back-tests (predict 4 weeks we already know); the most accurate one is used."""
    if len(y) < h + origins + 6:
        fc, lo, hi = holt(y, h)
        return fc, lo, hi, {"method": "Damped trend (Holt)", "mae": None, "naive_mae": None, "scores": {}}
    scores = {}
    for name, f in METHODS.items():
        errs = [np.mean(np.abs(f(y[:len(y) - h - o], h) - y[len(y) - h - o:len(y) - o])) for o in range(origins)]
        scores[name] = float(np.mean(errs))
    best = min(scores, key=scores.get)
    fc = METHODS[best](y, h)
    # 80% band from the chosen method's own back-test errors
    resid = np.concatenate([METHODS[best](y[:len(y) - h - o], h) - y[len(y) - h - o:len(y) - o] for o in range(origins)])
    sd = float(np.std(resid)) if len(resid) > 1 else 0.0
    band = 1.28 * sd * np.sqrt(np.arange(1, h + 1) / 2 + 0.5)
    last = METHODS[best](y[:-h], h)
    return fc, np.maximum(0, fc - band), fc + band, {
        "method": best, "mae": round(scores[best], 1), "naive_mae": round(scores["Last week repeated"], 1),
        "scores": {k: round(v, 1) for k, v in scores.items()}, "bt_actual": y[-h:], "bt_forecast": last}


def forecast_end(df):
    """Last day with normal data volume (ignores a thin tail, e.g. a few live test reviews)."""
    daily = df.set_index("timestamp").resample("D").size()
    ok = daily[daily >= 0.25 * daily[daily > 0].median()]
    return (ok.index.max() + pd.Timedelta(days=1)) if len(ok) else df.timestamp.max()


# ------------------------------------------------------------------ per-issue impact
def wilson(k, n, z=1.96):
    if n == 0:
        return (np.nan, np.nan)
    p = k / n; d = 1 + z * z / n; c = p + z * z / (2 * n); r = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return ((c - r) / d, (c + r) / d)


def issue_impact(df, issues, bundle, n_boot=300):
    fb = df[~df.excluded]
    end = forecast_end(df)
    X = bundle["X"]; rng = np.random.default_rng(0); out, series = [], {}
    for _, r in issues[issues.kind == "problem"].iterrows():
        rows = df.loc[r.member_ids]
        users = pd.Index(rows.user_id.unique()).intersection(X.index)
        known = X.loc[users].churned.dropna()
        risk = X.loc[users][X.loc[users].churned.isna()].index
        p_now = X.loc[users, "p_churn"]
        p_wo = _predict(bundle, fb.drop(index=r.member_ids, errors="ignore"), users)
        lift = (p_now - p_wo).clip(lower=0)
        rev = X.loc[users, "monthly_revenue"]
        lr, lrev = lift.loc[risk].values, (lift.loc[risk] * rev.loc[risk]).values
        if len(risk):
            idx = rng.integers(0, len(risk), (n_boot, len(risk)))
            bu, br = lr[idx].sum(1), lrev[idx].sum(1)
            now_u, now_r = lr.sum(), lrev.sum()
            now_u_lo, now_u_hi, now_r_lo, now_r_hi = *np.percentile(bu, [10, 90]), *np.percentile(br, [10, 90])
        else:
            now_u = now_r = now_u_lo = now_u_hi = now_r_lo = now_r_hi = 0.0
        y = weekly_users(rows[["timestamp", "user_id"]], end)
        fc, lo, hi, fmeta = forecast(y)
        scale = HORIZON_DAYS / 28
        new_u, new_lo, new_hi = fc.sum() * scale, lo.sum() * scale, hi.sum() * scale
        m_lift, m_rev = float(lift.mean()) if len(lift) else 0.0, float(rev.mean()) if len(rev) else 0.0
        fut_u, fut_r = new_u * m_lift, new_u * m_lift * m_rev
        k, n = int(known.sum()), int(len(known))
        ci = wilson(k, n)
        series[r.issue_id] = {"history": y, "forecast": fc, "lo": lo, "hi": hi, "end": end, "meta": fmeta}
        out.append(dict(
            issue_id=r.issue_id, title=r.title, area=r.area, affected=len(users), outcome_known=n, already_lost=k,
            observed_churn=k / n if n else np.nan, churn_ci_lo=ci[0], churn_ci_hi=ci[1], at_risk_now=len(risk),
            avg_p_churn=float(p_now.loc[risk].mean()) if len(risk) else np.nan,
            avg_p_if_fixed=float(p_wo.loc[risk].mean()) if len(risk) else np.nan,
            new_users_30d=new_u, new_users_lo=new_lo, new_users_hi=new_hi,
            users_lost_30d=now_u + fut_u, users_lost_lo=now_u_lo + new_lo * m_lift, users_lost_hi=now_u_hi + new_hi * m_lift,
            revenue_month=now_r + fut_r, revenue_lo=now_r_lo + new_lo * m_lift * m_rev,
            revenue_hi=now_r_hi + new_hi * m_lift * m_rev, avg_monthly_spend=m_rev))
    imp = pd.DataFrame(out)
    if len(imp):
        imp["revenue_12m"] = imp.revenue_month * 12
        imp = imp.sort_values("revenue_month", ascending=False).reset_index(drop=True)
    return imp, series


def overall(df, issues, bundle):
    """Whole-product view without double counting customers who appear in several issues."""
    X = bundle["X"]; risk = X[X.churned.isna()]
    ids = [i for m in issues[issues.kind == "problem"].member_ids for i in m]
    fb = df[~df.excluded]
    p_wo = _predict(bundle, fb.drop(index=ids, errors="ignore"), risk.index)
    lift = (risk.p_churn - p_wo).clip(lower=0)
    return {"at_risk": len(risk), "expected_leavers": float(risk.p_churn.sum()),
            "caused_by_issues": float(lift.sum()), "revenue_month": float((lift * risk.monthly_revenue).sum())}


def top_risk_customers(df, issue_row, bundle, n=10):
    X = bundle["X"]; rows = df.loc[issue_row.member_ids]
    users = pd.Index(rows.user_id.unique()).intersection(X.index)
    t = X.loc[users][X.loc[users].churned.isna()].sort_values("p_churn", ascending=False).head(n)
    last = rows.sort_values("timestamp").groupby("user_id").text.last()
    return pd.DataFrame({"Customer": t.index, "Chance of leaving": t.p_churn.map("{:.0%}".format),
                         "Monthly spend": t.monthly_revenue.map(inr), "Orders (90 days)": t.orders_90d.astype(int),
                         "Latest message": last.reindex(t.index).values})


def inr(x):
    """₹ with Indian digit grouping (12,34,567)."""
    if x is None or (isinstance(x, float) and np.isnan(x)):
        return "–"
    s = f"{int(round(x)):d}"; neg = s.startswith("-"); s = s.lstrip("-")
    head, tail = s[:-3], s[-3:]
    while len(head) > 2:
        tail = head[-2:] + "," + tail; head = head[:-2]
    return ("-" if neg else "") + "₹" + (head + "," if head else "") + tail


def short(x):
    """Compact ₹ for small cards: ₹2.07 lakh, ₹1.3 Cr."""
    if x is None or pd.isna(x):
        return "–"
    if abs(x) >= 1e7:
        return f"₹{x / 1e7:.2f} Cr"
    if abs(x) >= 1e5:
        return f"₹{x / 1e5:.2f} lakh"
    return inr(x)
