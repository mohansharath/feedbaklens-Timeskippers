"""Human-friendly downloads: clear column names, words instead of codes, formatted Excel files."""
import io
import pandas as pd
import pipeline as P
from theme import BERRY, CREAM

SEV = {0: "None (praise)", 1: "Low", 2: "Medium", 3: "High", 4: "Critical"}
SOURCE = {"app_review": "App review", "support_chat": "Support chat", "survey": "Survey", "social": "Social media",
          "appbazaar": "AppBazaar review", "feedbackform": "Feedback form", "upload": "Uploaded file", "api": "API"}
ACTION = {"accepted": "Accepted AI decision", "edited": "Corrected by human", "rejected": "Rejected (not a product issue)"}


def _sev(x):
    return SEV.get(int(round(x)), "") if pd.notna(x) else ""


def _date(x, fmt="%d %b %Y, %I:%M %p"):
    try:
        return pd.to_datetime(x).strftime(fmt)
    except Exception:
        return ""


def _stars(r):
    return "★" * int(r) + "☆" * (5 - int(r)) if pd.notna(r) and r else "No rating"


def _trend(g):
    word = "rising fast" if g >= 2 else "rising" if g >= 1.3 else "steady" if g >= 0.8 else "falling"
    return f"{g}× previous period ({word})"


def _yes(b):
    return "Yes" if bool(b) else "No"


def issues_table(problems, df, imp=None):
    from predict import inr
    im = imp.set_index("issue_id") if imp is not None and len(imp) else None
    rows = []
    for _, r in problems.iterrows():
        ins = P.insight(r)
        f = im.loc[r.issue_id] if im is not None and r.issue_id in im.index else None
        rows.append({
            "Rank": int(r.priority_rank), "Issue": r.title.split(": ", 1)[-1], "Product area": r.area,
            "Priority score (0-100)": r.priority, "Users affected": int(r.unique_users),
            "Feedback messages": int(r.records), "Severity": _sev(r.severity), "Trend": _trend(r.growth),
            "Average rating": f"{r.avg_rating} / 5" if pd.notna(r.avg_rating) else "No ratings",
            "Most mentioned": r.top_segment or "-",
            **({} if f is None else {
                "Predicted users lost (next 30 days)": f"{f.users_lost_30d:.0f} (likely {f.users_lost_lo:.0f}–{f.users_lost_hi:.0f})",
                "Revenue at risk per month": f"{inr(f.revenue_month)} (likely {inr(f.revenue_lo)}–{inr(f.revenue_hi)})",
                "Revenue at risk (12 months)": inr(f.revenue_12m),
                "Customers who already left": f"{f.already_lost} of {f.outcome_known} with known outcome"}),
            "Possible trigger": ins["possible_trigger"],
            "Why ranked here": "; ".join(f"{n} +{p} ({d})" for n, p, d in P.explain(r)),
            "Recommended next step": ins["recommended_investigation"],
            "Example customer quotes": " | ".join(f"“{str(df.at[j, 'text'])[:90]}”" for j in r.evidence_ids[:3]),
            "AI confidence": f"{r.confidence:.0%}",
            "First reported": _date(r.first_seen, "%d %b %Y"), "Last reported": _date(r.last_seen, "%d %b %Y")})
    return pd.DataFrame(rows)


def evidence_table(rows):
    return pd.DataFrame({
        "Feedback ID": rows.feedback_id, "Received": rows.timestamp.map(_date),
        "Source": rows.source.map(lambda s: SOURCE.get(s, str(s).replace("_", " ").title())),
        "Customer": rows.user_id, "Rating": rows.rating.map(_stars), "Customer message": rows.text.fillna("").str.replace("User:", "Customer:").str.replace(" | ", "\n"),
        "Tone": rows.sentiment.str.title(), "Severity": rows.severity.map(_sev),
        "Mentions": rows.segment.replace("", "-"), "Device": rows.platform.map(lambda p: {"ios": "iPhone (iOS)", "android": "Android"}.get(str(p).lower(), "-")),
        "App version": rows.app_version.fillna("-"), "AI confidence": rows.ai_confidence.map("{:.0%}".format),
        "Checked by a human": rows.verified.map(_yes), "Repeat from same customer": rows.is_repeat.map(_yes)})


def reviews_table(rv):
    return pd.DataFrame({
        "Reviewed on": rv.reviewed_at.map(_date), "Feedback ID": rv.feedback_id,
        "AI category": rv.ai_area, "AI severity": rv.ai_severity.map(_sev),
        "AI confidence": rv.ai_confidence.map("{:.0%}".format), "Human decision": rv.action.map(ACTION),
        "Final category": [h if a == "edited" else ("Excluded" if a == "rejected" else ai)
                           for a, h, ai in zip(rv.action, rv.human_area, rv.ai_area)],
        "Final severity": [(_sev(h) if pd.notna(h) else _sev(s)) if a != "rejected" else "-"
                           for a, h, s in zip(rv.action, rv.human_severity, rv.ai_severity)],
        "Reason / note": rv.reason.fillna(""), "Reviewer": rv.reviewer})


def to_excel(sheets: dict) -> bytes:
    """Formatted .xlsx: berry header, frozen top row, filters, sensible widths, wrapped text."""
    from openpyxl.styles import Alignment, Font, PatternFill
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as xw:
        for name, d in sheets.items():
            d.to_excel(xw, sheet_name=name[:31], index=False)
            ws = xw.sheets[name[:31]]
            for c in ws[1]:
                c.font = Font(bold=True, color="FFFFFF"); c.fill = PatternFill("solid", fgColor=BERRY[1:])
                c.alignment = Alignment(vertical="center", wrap_text=True)
            for i, col in enumerate(d.columns, start=1):
                longest = max([len(str(col))] + [len(str(v)) for v in d[col].head(200)])
                ws.column_dimensions[ws.cell(1, i).column_letter].width = min(60, max(10, longest + 2))
            for row in ws.iter_rows(min_row=2):
                for c in row:
                    c.alignment = Alignment(vertical="top", wrap_text=True)
            for r in range(2, ws.max_row + 1, 2):
                for c in ws[r]:
                    c.fill = PatternFill("solid", fgColor=CREAM[1:])
            ws.freeze_panes = "A2"; ws.auto_filter.ref = ws.dimensions
    return buf.getvalue()


XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
