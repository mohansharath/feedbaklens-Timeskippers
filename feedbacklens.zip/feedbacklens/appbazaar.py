"""AppBazaar — a mini app store where users rate and review apps.  Run: streamlit run appbazaar.py --server.port 8502"""
import streamlit as st
import db
import theme  # noqa: F401  (shared look)
from client import send_feedback

st.set_page_config(page_title="AppBazaar", page_icon="🛍️", layout="centered")
theme.apply(st)
db.init_db()
apps = db.list_apps()
qp = st.query_params
current = qp.get("app")

if not current:
    st.title("🛍️ AppBazaar")
    q = st.text_input("Search applications…", "")
    for a in [a for a in apps if q.lower() in (a["name"] + a["category"]).lower()]:
        with st.container(border=True):
            c1, c2 = st.columns([5, 1])
            c1.markdown(f"### {a['icon']} {a['name']}\n{a['category']} · ⭐ {a['rating'] or '–'} "
                        f"({a['n_ratings']:,} ratings)\n\n{a['description']}")
            if c2.button("Open", key=a["app_id"]):
                st.query_params["app"] = a["app_id"]; st.rerun()
    st.stop()

a = db.get_app(current)
if st.button("← All apps"):
    st.query_params.clear(); st.rerun()
st.title(f"{a['icon']} {a['name']}")
st.markdown(f"**{a['category']}** · {a['developer']}")
c = st.columns(3)
c[0].metric("Rating", f"⭐ {a['rating'] or '–'}")
c[1].metric("Reviews", f"{a['n_ratings']:,}")
c[2].button("Install", type="primary", width="stretch")
st.markdown(f"**About this app**  \n{a['description']}")

st.subheader("✍️ Write a review")
with st.form("review", clear_on_submit=True):
    rating = st.feedback("stars")
    text = st.text_area("Tell others about your experience", placeholder="e.g. UPI payment failed again")
    user = st.text_input("Your user ID (optional)", placeholder="U01024")
    platform = st.radio("Device", ["android", "ios"], horizontal=True)
    if st.form_submit_button("Submit review", type="primary"):
        if rating is None and not text.strip():
            st.warning("Please add a rating or a comment.")
        else:
            fid, via = send_feedback({"app_id": current, "user_id": user or None, "rating": (rating + 1) if rating is not None else None,
                                      "source": "appbazaar", "feedback_text": text, "platform": platform, "app_version": "v4.2"})
            st.success(f"Thanks! Review saved as **{fid}** (sent via {via}). It's now visible to the {a['name']} product team.")

st.subheader("Reviews")
for _, r in db.get_feedback(current, 15).iterrows():
    if r.text and r.source in ("appbazaar", "app_review") and "User:" not in r.text:
        stars = "⭐" * int(r.rating) if r.rating == r.rating and r.rating else ""
        st.markdown(f"{stars}  \n“{r.text}”  \n<sub>{r.user_id} · {str(r.timestamp)[:10]}</sub>", unsafe_allow_html=True)
        st.divider()
