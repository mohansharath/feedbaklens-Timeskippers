"""One place for the FeedbackLens look: Deep Berry + Vanilla Cloud.
The colours are applied in code (CSS), so they work however the app is started."""
import plotly.graph_objects as go
import plotly.io as pio

VERSION = "2.5"
BERRY, VANILLA = "#FC6C26", "#FFF8DF"
CREAM, INK, MUTED, GRID = "#FFEFC2", "#3B2A1E", "#7A6A58", "#EFE3C2"
BERRY_DARK = "#D9531A"
GRAY = "#B5AC9A"
# validated (colour-blind safe) chart palette on the vanilla background; berry always first
SERIES = ["#FC6C26", "#2a78d6", "#1baf7a", "#8a4fbf", "#eda100", "#e87ba4"]

pio.templates["feedbacklens"] = go.layout.Template(layout=dict(
    paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", colorway=SERIES,
    font=dict(color=INK), xaxis=dict(gridcolor=GRID, zerolinecolor=GRID),
    yaxis=dict(gridcolor=GRID, zerolinecolor=GRID)))
pio.templates.default = "plotly+feedbacklens"

CSS = f"""<style>
.stApp, [data-testid="stAppViewContainer"], [data-testid="stHeader"] {{ background-color: {VANILLA} !important; color: {INK}; }}
[data-testid="stSidebar"], [data-testid="stSidebar"] > div {{ background-color: {CREAM} !important; }}
h1, h2, h3, h4, p, label, li, span {{ color: {INK}; }}
/* buttons */
.stButton > button, .stDownloadButton > button, .stFormSubmitButton > button, .stLinkButton > a {{
  border: 1.5px solid {BERRY} !important; color: {BERRY} !important; background: #fff !important; border-radius: 10px !important; }}
.stButton > button:hover, .stDownloadButton > button:hover, .stFormSubmitButton > button:hover {{ background: {BERRY} !important; color: #fff !important; }}
.stButton > button[kind="primary"], .stFormSubmitButton > button[kind="primary"], .stButton > button[data-testid="stBaseButton-primary"],
.stFormSubmitButton > button[data-testid="stBaseButton-primary"] {{ background: {BERRY} !important; color: #fff !important; }}
.stButton > button p, .stDownloadButton > button p, .stFormSubmitButton > button p {{ color: inherit !important; }}
/* tabs */
[data-baseweb="tab-highlight"] {{ background-color: {BERRY} !important; }}
button[role="tab"][aria-selected="true"] p {{ color: {BERRY} !important; font-weight: 700; }}
/* slider, toggle, radio, checkbox */
[data-testid="stSlider"] [role="slider"] {{ background-color: {BERRY} !important; border-color: {BERRY} !important; }}
[data-testid="stSliderThumbValue"] {{ color: {BERRY} !important; }}
input[type="checkbox"], input[type="radio"] {{ accent-color: {BERRY}; }}
/* inputs, cards, tables, metrics */
[data-baseweb="input"], [data-baseweb="select"] > div, [data-baseweb="textarea"] {{ background-color: #fff !important; border-color: {GRID} !important; }}
[data-testid="stVerticalBlockBorderWrapper"] {{ background-color: #fffdf6; border-color: {GRID} !important; border-radius: 14px; }}
[data-testid="stExpander"] details {{ background-color: #fffdf6; border-color: {GRID} !important; border-radius: 12px; }}
[data-testid="stMetricValue"] {{ color: {INK}; }}
[data-testid="stMetric"] {{ background: #fffdf6; border: 1px solid {GRID}; border-left: 5px solid {BERRY}; border-radius: 12px; padding: 10px 14px; }}
a {{ color: {BERRY_DARK}; }}
.fl-version {{ display:inline-block; background:{BERRY}; color:#fff; border-radius:999px; padding:2px 10px; font-size:12px; font-weight:600; }}
</style>"""


def apply(st, show_version=False):
    """Call right after st.set_page_config()."""
    st.markdown(CSS, unsafe_allow_html=True)
    if show_version:
        st.sidebar.markdown(f'<span class="fl-version">Version {VERSION} · Deep Berry theme</span>', unsafe_allow_html=True)
