"""Tiny client used by AppBazaar and FeedbackForm. They only know the API contract, never the analysis."""
import os
import requests
import db

API = os.getenv("FEEDBACKLENS_API", "http://localhost:8000/api/v1")


def send_feedback(payload: dict):
    """POST to the API. If the API is down, store directly so a live demo never breaks."""
    try:
        r = requests.post(f"{API}/feedback", json=payload, timeout=5)
        r.raise_for_status()
        return r.json()["feedback_id"], "API"
    except Exception:
        db.init_db()
        return db.insert_feedback(payload), "direct DB (API offline)"
