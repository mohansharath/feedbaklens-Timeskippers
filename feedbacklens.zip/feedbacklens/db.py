"""Shared feedback store (SQLite). Every source writes here; FeedbackLens reads from here.
Swap the connection for PostgreSQL in production — the tables stay the same."""
import os, sqlite3, uuid, json, random
from datetime import datetime
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).parent
DB_PATH = os.getenv("FEEDBACKLENS_DB", str(ROOT / "data" / "feedbacklens.db"))

SCHEMA = """
CREATE TABLE IF NOT EXISTS apps (app_id TEXT PRIMARY KEY, name TEXT, icon TEXT, category TEXT,
    developer TEXT, description TEXT);
CREATE TABLE IF NOT EXISTS forms (form_id TEXT PRIMARY KEY, app_id TEXT, title TEXT, description TEXT,
    question TEXT, areas TEXT, active INTEGER DEFAULT 1, created_at TEXT);
CREATE TABLE IF NOT EXISTS feedback (feedback_id TEXT PRIMARY KEY, app_id TEXT, form_id TEXT, user_id TEXT,
    timestamp TEXT, source TEXT, rating REAL, product_area TEXT, text TEXT, app_version TEXT, platform TEXT,
    received_at TEXT);
CREATE TABLE IF NOT EXISTS reviews (review_id INTEGER PRIMARY KEY AUTOINCREMENT, feedback_id TEXT,
    ai_area TEXT, ai_severity INTEGER, ai_confidence REAL, action TEXT, human_area TEXT, human_severity INTEGER,
    reason TEXT, reviewer TEXT, reviewed_at TEXT);
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS customers (user_id TEXT PRIMARY KEY, tenure_days INTEGER, orders_90d INTEGER,
    avg_order_value REAL, churned REAL);
"""
APPS = [("shopflow", "ShopFlow", "🛒", "Shopping", "ShopFlow Pvt Ltd", "Smart shopping with UPI checkout and fast delivery."),
        ("studyx", "StudyX", "📚", "Education", "StudyX Labs", "Bite-sized lessons and exam practice."),
        ("fittrack", "FitTrack", "🏃", "Health & Fitness", "FitTrack Inc", "Track workouts, steps and sleep.")]


def conn():
    Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(DB_PATH, timeout=15)
    c.execute("PRAGMA journal_mode=WAL")   # many devices can write while the dashboard reads
    c.row_factory = sqlite3.Row
    return c


def now():
    return datetime.now().isoformat(timespec="seconds")


def init_db(seed=True):
    with conn() as c:
        c.executescript(SCHEMA)
        if seed and not c.execute("SELECT COUNT(*) FROM customers").fetchone()[0]:
            cust = ROOT / "data" / "customers.csv"
            if not cust.exists():
                import generate_data; generate_data.main(str(ROOT / "data" / "sample_feedback.csv"))
            cd = pd.read_csv(cust)
            c.executemany("INSERT OR REPLACE INTO customers VALUES (?,?,?,?,?)",
                          cd.astype(object).where(cd.notna(), None).values.tolist())
        if not seed or c.execute("SELECT COUNT(*) FROM apps").fetchone()[0]:
            return
        c.executemany("INSERT INTO apps VALUES (?,?,?,?,?,?)", APPS)
        csv = ROOT / "data" / "sample_feedback.csv"
        if not csv.exists():
            import generate_data; generate_data.main(str(csv))
        df = pd.read_csv(csv)
        df = df.assign(app_id="shopflow", form_id=None, product_area=None, received_at=df.timestamp)
        cols = ["feedback_id", "app_id", "form_id", "user_id", "timestamp", "source", "rating", "product_area",
                "text", "app_version", "platform", "received_at"]
        c.executemany(f"INSERT INTO feedback ({','.join(cols)}) VALUES ({','.join('?'*len(cols))})",
                      df[cols].astype(object).where(df[cols].notna(), None).values.tolist())
        random.seed(1)  # a few reviews for the other demo apps so the store isn't empty
        demo = {"studyx": [(5, "Great lessons, very clear"), (4, "Love the practice tests"), (2, "Videos buffer a lot"),
                           (1, "App crashes during quiz"), (3, "Need dark mode")],
                "fittrack": [(5, "Step counter is accurate"), (2, "Sleep tracking stopped syncing"),
                             (4, "Nice workout plans"), (1, "Login keeps failing")]}
        for app, revs in demo.items():
            for r, t in revs:
                c.execute("INSERT INTO feedback (feedback_id, app_id, user_id, timestamp, source, rating, text, "
                          "platform, received_at) VALUES (?,?,?,?,?,?,?,?,?)",
                          (new_id(), app, f"U{random.randint(1, 4000):05d}", "2026-09-10T10:00", "appbazaar", r, t, "android", now()))
        c.execute("INSERT OR REPLACE INTO meta VALUES ('last_processed_count', ?)", (str(len(df) + 9),))


def new_id(prefix="FB"):
    return f"{prefix}-{uuid.uuid4().hex[:8].upper()}"


# ---------------------------------------------------------------- feedback
def insert_feedback(d: dict) -> str:
    fid = new_id()
    with conn() as c:
        c.execute("INSERT INTO feedback (feedback_id, app_id, form_id, user_id, timestamp, source, rating, product_area, "
                  "text, app_version, platform, received_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                  (fid, d.get("app_id"), d.get("form_id"), d.get("user_id") or f"anon-{uuid.uuid4().hex[:6]}",
                   d.get("timestamp") or now(), d.get("source", "api"), d.get("rating"), d.get("product_area"),
                   d.get("feedback_text") or d.get("text") or "", d.get("app_version"), d.get("platform"), now()))
    return fid


def get_feedback(app_id=None, limit=None) -> pd.DataFrame:
    q = "SELECT * FROM feedback" + (" WHERE app_id = ?" if app_id else "") + " ORDER BY received_at DESC"
    q += f" LIMIT {int(limit)}" if limit else ""
    with conn() as c:
        return pd.read_sql_query(q, c, params=[app_id] if app_id else None)


def count_feedback(app_id=None) -> int:
    with conn() as c:
        return c.execute("SELECT COUNT(*) FROM feedback" + (" WHERE app_id=?" if app_id else ""),
                         [app_id] if app_id else []).fetchone()[0]


# ---------------------------------------------------------------- apps
def list_apps():
    with conn() as c:
        return [dict(r) for r in c.execute(
            "SELECT a.*, ROUND(AVG(f.rating),1) AS rating, COUNT(f.rating) AS n_ratings FROM apps a "
            "LEFT JOIN feedback f ON f.app_id = a.app_id GROUP BY a.app_id ORDER BY COUNT(f.feedback_id) DESC")]


def get_app(app_id):
    return next((a for a in list_apps() if a["app_id"] == app_id), None)


# ---------------------------------------------------------------- forms
def create_form(app_id, title, description, question, areas) -> str:
    fid = new_id("FORM")
    with conn() as c:
        c.execute("INSERT INTO forms VALUES (?,?,?,?,?,?,1,?)",
                  (fid, app_id, title, description, question, json.dumps(areas), now()))
    return fid


def get_form(form_id):
    with conn() as c:
        r = c.execute("SELECT * FROM forms WHERE form_id=?", (form_id,)).fetchone()
    return {**dict(r), "areas": json.loads(r["areas"] or "[]")} if r else None


def list_forms():
    with conn() as c:
        rows = c.execute("SELECT f.*, (SELECT COUNT(*) FROM feedback x WHERE x.form_id=f.form_id) AS responses "
                         "FROM forms f ORDER BY created_at DESC").fetchall()
    return [{**dict(r), "areas": json.loads(r["areas"] or "[]")} for r in rows]


# ---------------------------------------------------------------- human reviews (HITL)
def add_reviews(rows: list):
    with conn() as c:
        c.executemany("INSERT INTO reviews (feedback_id, ai_area, ai_severity, ai_confidence, action, human_area, "
                      "human_severity, reason, reviewer, reviewed_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
                      [(r["feedback_id"], r["ai_area"], r["ai_severity"], r["ai_confidence"], r["action"],
                        r.get("human_area"), r.get("human_severity"), r.get("reason", ""), r.get("reviewer", "PM"), now())
                       for r in rows])


def get_reviews() -> pd.DataFrame:
    with conn() as c:
        return pd.read_sql_query("SELECT * FROM reviews ORDER BY review_id", c)


def get_customers() -> pd.DataFrame:
    """Customer activity used by the Impact Forecast (in production: your orders / CRM database)."""
    with conn() as c:
        return pd.read_sql_query("SELECT * FROM customers", c)


def get_meta(key, default=None):
    with conn() as c:
        r = c.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
    return r[0] if r else default


def set_meta(key, value):
    with conn() as c:
        c.execute("INSERT OR REPLACE INTO meta VALUES (?,?)", (key, str(value)))


if __name__ == "__main__":
    init_db(); print(f"DB ready at {DB_PATH}: {count_feedback()} feedback records")
