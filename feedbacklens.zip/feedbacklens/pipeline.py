"""FeedbackLens pipeline: messy feedback -> prioritised, traceable product issues.

Steps: ingest -> normalize -> understand (area, sentiment, severity, segment, impact)
       -> embed + cluster into issues -> impact & trend analytics -> priority score -> insight.
Runs fully offline (TF-IDF embeddings). Optional: Claude API for richer summaries.
"""
import re, os, json
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
from sklearn.preprocessing import normalize as l2
from sklearn.cluster import AgglomerativeClustering
from scipy.sparse import hstack

# ---------------------------------------------------------------- 1. NORMALIZE
TYPOS = {r"\bpaymnt\b|\bpaymet\b|\bpymnt\b|\bpayement\b": "payment", r"\bisnt\b": "is not",
         r"\bcant\b|\bcan't\b|\bcannot\b|\bunable to\b|\bnot able to\b": "cannot", r"\bdoesn'?t\b": "does not",
         r"\bpls\b|\bplz\b": "please", r"\blogn\b": "login", r"\bsign ?in\b|\blog ?in\b": "login"}
SYNONYMS = {  # used only for grouping (the original text is always kept for evidence)
    r"\bg ?pay\b|\bgoogle pay\b|\bphone ?pe\b|\bpaytm\b|\bbhim\b": "upi", r"\btrans?ac?t?\w*|\btxn\b": "payment",
    r"\bdebited\b|\bcharged\b": "deducted", r"nahi ho raha|nahi hua": "not working", r"\bamount\b": "money"}
EMOJI_NEG, EMOJI_POS = "😡😭🙄😤👎💔", "👍😍❤🙂😊🔥🙏"


def extract_customer_text(t):
    """Support chats: keep only what the customer said."""
    if "User:" in t:
        return " ".join(p.split("User:", 1)[1].strip() for p in t.split("|") if "User:" in p)
    return t


def normalize(t):
    t = extract_customer_text(str(t)).lower()
    for pat, rep in TYPOS.items():
        t = re.sub(pat, rep, t)
    t = re.sub(r"(.)\1{2,}", r"\1\1", t)            # sooooo -> soo, !!!! -> !!
    t = re.sub(r"[^\w\s'.,!?]", " ", t)              # drop emojis/symbols (sentiment captured separately)
    return re.sub(r"\s+", " ", t).strip()


def canonical(t):
    for pat, rep in SYNONYMS.items():
        t = re.sub(pat, rep, t)
    return t


# ---------------------------------------------------------------- 2. UNDERSTAND
AREAS = [  # (product area, keywords) - order = tie-break priority
    ("Payments", r"pay|upi|deducted|refund|money|bank|charged|debited"),
    ("Orders", r"order (not|wasn|was not|failed|cancel|didn)|order confirmation|not placed|no order"),
    ("Checkout", r"checkout|cart|place order|order button"),
    ("Stability", r"crash|freez|closes|hang"),
    ("Login & Account", r"login|otp|password|account|logged out|log back"),
    ("Performance", r"slow|lag|loading|takes forever|spinner"),
    ("Delivery", r"deliver|courier|tracking"),
    ("Notifications", r"notification|spam"),
    ("Search", r"search|filter|results"),
    ("UI & Design", r"font|dark mode|color|colour|ui\b|design|layout|dashboard"),
]
SEV = [(4, r"deducted|charged twice|refund|money gone|lost money|fraud|hacked|data lost"),
       (3, r"fail|not working|crash|cannot|error|stuck|never arrives|does not work|not received|irrelevant|not placed"),
       (2, r"slow|loading|lag|late|delay|forever|spam|annoying|too many|expired"),
       (1, r"font|color|dark mode|please add|would be nice|request|suggest")]
NEG = r"fail|not|worst|terrible|hate|slow|crash|cannot|bad|never|stuck|late|spam|irrelevant|problem|issue|error|angry|ugly"
POS = r"love|great|amazing|best|smooth|awesome|good|fast|nice|thanks"
IMPACT = r"refund|deducted|uninstall|switch|cancel|never again|deleting|moving to|lost money|charged"
SEGMENTS = {"UPI": r"upi|gpay|google pay|phonepe|paytm", "Card": r"\bcard\b|credit|debit card", "OTP/SMS": r"otp|sms"}


def sentiment(raw, norm, rating):
    s = len(re.findall(POS, norm)) - len(re.findall(NEG, norm))
    s += sum(c in EMOJI_POS for c in raw) - sum(c in EMOJI_NEG for c in raw)
    if rating != "" and not pd.isna(rating):
        s += (float(rating) - 3)
    if re.search(POS, norm) and re.search(r"\bbut\b", norm):
        return "mixed"
    return "positive" if s > 0 else "negative" if s < 0 else "neutral"


def understand(df):
    df = df.copy()
    df["text"] = df["text"].fillna("").astype(str)
    df["rating"] = pd.to_numeric(df["rating"], errors="coerce")
    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce", format="ISO8601")
    df["clean"] = df["text"].map(normalize)
    df["canon"] = df["clean"].map(canonical)
    df["area"] = df["canon"].map(lambda t: next((a for a, p in AREAS if re.search(p, t)), "General"))
    df["n_areas"] = df["canon"].map(lambda t: sum(bool(re.search(p, t)) for _, p in AREAS))
    if "product_area" in df:  # area the customer picked in a form = a hint when the text itself is vague
        hint = df["product_area"].fillna("").astype(str)
        use = (df["area"] == "General") & hint.isin([a for a, _ in AREAS])
        df.loc[use, "area"] = hint[use]
    df["severity"] = df["canon"].map(lambda t: next((s for s, p in SEV if re.search(p, t)), 2))
    df["sentiment"] = [sentiment(r, n, g if not pd.isna(g) else "") for r, n, g in zip(df.text, df.clean, df.rating)]
    pos = df.sentiment == "positive"
    df.loc[pos, "severity"] = 0; df.loc[pos, "area"] = "Praise"   # praise is tracked, but is not a problem
    df["business_impact"] = df["canon"].str.contains(IMPACT) | (df["rating"] <= 1)
    df["segment"] = df["clean"].map(lambda t: next((k for k, p in SEGMENTS.items() if re.search(p, t)), ""))
    df["shouting"] = df["text"].map(lambda t: sum(c.isupper() for c in t) > 0.6 * max(1, sum(c.isalpha() for c in t)))
    # exact duplicates from the same person = spam/repeat, kept for traceability but flagged
    df["is_repeat"] = df.duplicated(subset=["user_id", "canon"], keep="first") & (df["canon"] != "")
    df[["ai_confidence", "conf_reasons"]] = [ai_confidence(r) for r in df.itertuples()]
    df["ai_area"], df["ai_severity"] = df["area"], df["severity"]      # AI's original answer is never overwritten
    df["verified"], df["excluded"] = False, False
    df["needs_review"] = (df.canon != "") & ((df.ai_confidence < REVIEW_THRESHOLD) |
                                              ((df.severity == 4) & (df.ai_confidence < 0.85)))
    return df


# ---------------------------------------------------------------- 2b. AI CONFIDENCE + HUMAN-IN-THE-LOOP
REVIEW_THRESHOLD = 0.6
HUMAN_AREAS = [a for a, _ in AREAS] + ["General"]


def ai_confidence(r):
    """How sure is the AI about its reading of ONE message? Returns (score, reasons). Transparent rules."""
    if not r.canon:
        return 1.0, "rating only"
    c, why = 0.92, []
    if r.area == "General" and r.sentiment != "positive":
        c -= 0.45; why.append("no clear product area")
    if r.n_areas >= 2:
        c -= 0.22; why.append(f"matches {r.n_areas} product areas")
    if len(r.canon.split()) < 4:
        c -= 0.12; why.append("very short / vague")
    if r.sentiment == "mixed":
        c -= 0.2; why.append("mixed sentiment")
    if not pd.isna(r.rating) and ((r.rating <= 2 and r.sentiment == "positive") or (r.rating >= 4 and r.sentiment == "negative")):
        c -= 0.2; why.append("rating contradicts text")
    return round(float(np.clip(c, 0.05, 0.98)), 2), "; ".join(why) or "clear signal"


def apply_reviews(df, reviews):
    """Human decisions override the AI: accepted -> verified, edited -> new area/severity, rejected -> excluded."""
    if reviews is None or len(reviews) == 0:
        return df
    df = df.copy()
    rv = reviews.drop_duplicates("feedback_id", keep="last").set_index("feedback_id")
    idx = df.index[df.feedback_id.isin(rv.index)]
    for i in idx:
        r = rv.loc[df.at[i, "feedback_id"]]
        df.at[i, "verified"], df.at[i, "needs_review"], df.at[i, "ai_confidence"] = True, False, 1.0
        if r.action == "edited":
            df.at[i, "area"] = r.human_area or df.at[i, "area"]
            if not pd.isna(r.human_severity):
                df.at[i, "severity"] = int(r.human_severity)
        elif r.action == "rejected":
            df.at[i, "excluded"] = True
    return df


# ---------------------------------------------------------------- 3. EMBED + CLUSTER
def embed(texts):
    """Word + character n-gram TF-IDF (robust to typos) -> 100-d dense vectors (LSA)."""
    md = 2 if len(texts) >= 30 else 1
    w = TfidfVectorizer(ngram_range=(1, 2), min_df=md).fit_transform(texts)
    c = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), min_df=md).fit_transform(texts)
    X = hstack([w, c * 0.7]).tocsr()
    k = min(100, X.shape[1] - 1, X.shape[0] - 1)
    return l2(TruncatedSVD(k, random_state=0).fit_transform(X)) if k > 1 else l2(X.toarray())


def cluster(df, threshold=0.93, min_size=4):
    """Cluster within each product area -> area / sub-issue hierarchy."""
    df = df.copy(); df["issue_id"] = -1
    text_mask = (df["canon"].str.len() > 0) & ~df["excluded"]
    emb = embed(df.loc[text_mask, "canon"].tolist())
    X_all = np.zeros((len(df), emb.shape[1])); X_all[text_mask.values] = emb
    next_id = 0
    for area, idx in df[text_mask].groupby("area").groups.items():
        idx = list(idx); X = X_all[df.index.get_indexer(idx)]
        if len(idx) < 3:
            labels = np.zeros(len(idx), int)
        else:
            labels = AgglomerativeClustering(n_clusters=None, distance_threshold=threshold, metric="cosine",
                                             linkage="average").fit_predict(X)
        sizes = pd.Series(labels).value_counts()
        small = set(sizes[sizes < min_size].index)
        for lab in sorted(set(labels)):
            members = [i for i, l in zip(idx, labels) if l == lab]
            if lab in small:
                continue
            df.loc[members, "issue_id"] = next_id; next_id += 1
        leftovers = [i for i, l in zip(idx, labels) if l in small]
        if leftovers:
            df.loc[leftovers, "issue_id"] = next_id; next_id += 1
    return df, X_all


def label_issues(df, X):
    """Name each cluster with its most distinctive words (class-based TF-IDF) + a representative quote."""
    sub = df[df.issue_id >= 0]
    docs = sub.groupby("issue_id")["canon"].apply(" ".join)
    vec = TfidfVectorizer(ngram_range=(1, 2), stop_words="english", max_df=0.5 if len(docs) >= 4 else 1.0, sublinear_tf=True)
    M = vec.fit_transform(docs.values); terms = np.array(vec.get_feature_names_out())
    info = {}
    for row, iid in enumerate(docs.index):
        top = terms[M[row].toarray()[0].argsort()[::-1][:6]]
        picked = []
        for t in top:  # avoid 'upi' + 'upi failed' duplicates
            if not any(t in p or p in t for p in picked):
                picked.append(t)
        rows = sub.index[sub.issue_id == iid]
        V = X[df.index.get_indexer(rows)]; centroid = V.mean(0)
        sims = V @ centroid / (np.linalg.norm(centroid) + 1e-9)
        order = rows[np.argsort(-sims)]
        s = sub.loc[rows]; s = s[s.sentiment == "negative"] if (s.sentiment == "negative").any() else s
        phr = s["clean"].str.strip(" .!?")
        phr = phr[(phr.str.len() >= 3) & (phr.str.len() <= 60)].value_counts()
        rep = phr.index[0] if len(phr) else " ".join(picked[:2])   # most common wording = cleanest label
        info[iid] = {"keywords": picked[:3], "label": rep.strip(" .!?").capitalize(), "cohesion": float(sims.mean()), "evidence_ids": list(order[:8])}
    return info


# ---------------------------------------------------------------- 4. ANALYTICS + PRIORITY
DEFAULT_WEIGHTS = {"reach": 0.35, "severity": 0.30, "trend": 0.20, "business": 0.15}
RELEASES = {"v4.0": "2026-06-01", "v4.1": "2026-07-15", "v4.2": "2026-08-20"}


def trend_stats(ts, end, recent_days=28, base_days=56):
    recent = ((ts > end - pd.Timedelta(days=recent_days))).sum() / recent_days
    base = ((ts <= end - pd.Timedelta(days=recent_days)) & (ts > end - pd.Timedelta(days=recent_days + base_days))).sum() / base_days
    growth = (recent + 0.05) / (base + 0.05)
    weekly = ts.dt.to_period("W").value_counts().sort_index()
    spike = None
    if len(weekly) >= 4:
        for i in range(3, len(weekly)):
            prev = weekly.iloc[:i]
            if weekly.iloc[i] > prev.mean() + 2.5 * prev.std(ddof=0) + 2 and weekly.iloc[i] >= 1.8 * prev.mean():
                spike = weekly.index[i].start_time; break
    return recent, base, growth, spike


def build_issues(df, info, weights=None, releases=None):
    weights = weights or DEFAULT_WEIGHTS
    releases = {k: pd.Timestamp(v) for k, v in (releases or RELEASES).items()}
    end = df["timestamp"].max()
    rows = []
    for iid, g in df[df.issue_id >= 0].groupby("issue_id"):
        neg = g[g.sentiment != "positive"]
        kind = "praise" if g.area.iloc[0] == "Praise" else "problem"
        users = g.user_id.nunique()
        top_user_share = g.user_id.value_counts(normalize=True).iloc[0]
        recent, base, growth, spike = trend_stats(g.timestamp, end)
        trig = None
        if spike is not None:
            before = [(v, d) for v, d in releases.items() if d <= spike + pd.Timedelta(days=7)]
            if before and (spike - before[-1][1]).days <= 21:
                trig = before[-1][0]
        seg = g.segment[g.segment != ""].value_counts()
        a = info[iid]
        rows.append(dict(
            issue_id=iid, kind=kind, area=g.area.mode()[0],
            title=f"{g.area.mode()[0]}: {a['label']}", keywords=", ".join(a["keywords"]),
            records=len(g), unique_users=users, repeats=int(g.is_repeat.sum()),
            top_user_share=round(top_user_share, 2), avg_rating=round(g.rating.mean(), 2) if g.rating.notna().any() else None,
            severity=round(neg.severity.mean() if len(neg) else 0, 2),
            pct_critical=round((g.severity == 4).mean(), 2), business_share=round(g.business_impact.mean(), 2),
            recent_per_day=round(recent, 2), base_per_day=round(base, 2), growth=round(growth, 2),
            spike_week=spike, possible_trigger=trig,
            top_segment=seg.index[0] if len(seg) else "", segment_share=round(seg.iloc[0] / len(g), 2) if len(seg) else 0,
            platform_split=g.platform.value_counts(normalize=True).round(2).to_dict() if "platform" in g else {},
            first_seen=g.timestamp.min(), last_seen=g.timestamp.max(),
            cohesion=round(a["cohesion"], 2), evidence_ids=a["evidence_ids"], member_ids=list(g.index)))
    issues = pd.DataFrame(rows)
    if not issues.empty:
        issues["possible_trigger"] = issues["possible_trigger"].fillna("")
    if issues.empty:
        return issues
    return score(issues, weights)


def score(issues, weights):
    """Transparent priority score (0-100). Every component is shown in the UI."""
    iss = issues.copy()
    p = iss.kind == "problem"
    max_users = iss.loc[p, "unique_users"].max() or 1
    iss["c_reach"] = np.sqrt(iss.unique_users / max_users)                 # unique people, NOT message volume
    iss["c_severity"] = iss.severity / 4
    iss["c_trend"] = np.clip((iss.growth - 1) / 3, 0, 1)                   # 4x growth = max
    iss["c_business"] = np.clip(iss.business_share / 0.6, 0, 1)
    tot = sum(weights.values()) or 1
    iss["priority"] = 100 * sum(weights[k] * iss[f"c_{k}"] for k in weights) / tot
    iss.loc[~p, "priority"] = 0
    iss["priority"] = iss.priority.round(1)
    iss["confidence"] = (0.5 * np.clip(iss.cohesion, 0, 1) + 0.5 * np.clip(np.log10(iss.records) / 2, 0, 1)).round(2)
    iss["volume_rank"] = iss.records.rank(ascending=False, method="first").astype(int)
    iss = iss.sort_values(["kind", "priority"], ascending=[False, False]).reset_index(drop=True)
    iss["priority_rank"] = np.where(iss.kind == "problem", np.arange(1, len(iss) + 1), 0)
    return iss


def explain(r, weights=None):
    """Human-readable 'why is this ranked here?'"""
    w = weights or DEFAULT_WEIGHTS; tot = sum(w.values())
    parts = [("Reach", "reach", f"{r.unique_users} unique users"),
             ("Severity", "severity", f"avg {r.severity}/4, {int(r.pct_critical*100)}% critical"),
             ("Trend", "trend", f"{r.growth}x vs previous 8 weeks"),
             ("Business impact", "business", f"{int(r.business_share*100)}% mention money loss / churn / 1★")]
    return [(n, round(100 * w[k] * r[f"c_{k}"] / tot, 1), d) for n, k, d in parts]


# ---------------------------------------------------------------- 5. INSIGHT / DECISION
NEXT_STEP = {
    "Payments": "Compare payment-gateway success/timeout rates before vs after the suspected release; reconcile debited-but-failed orders and trigger auto-refunds.",
    "Checkout": "Profile checkout API latency and front-end spinner states; check for timeouts introduced in the latest release.",
    "Login & Account": "Check OTP/SMS provider delivery latency and login error logs by carrier and platform.",
    "Stability": "Pull crash reports (Crashlytics/Sentry) grouped by app version and device.",
    "Performance": "Run performance traces on the slowest screens; compare with previous release.",
    "Delivery": "Review logistics partner SLAs and tracking-update pipeline.",
    "Notifications": "Audit notification frequency caps and promotional campaign settings.",
    "Search": "Evaluate search relevance on the failing queries; check index freshness.",
    "UI & Design": "Validate with a small usability test before investing design time.",
}


def insight(r):
    trend = "increasing sharply" if r.growth >= 2 else "increasing" if r.growth >= 1.3 else "stable" if r.growth >= 0.8 else "decreasing"
    txt = {
        "headline": f"{r.title} — {trend}",
        "what_we_know": (f"{r.records} feedback records from {r.unique_users} unique users. Avg rating "
                         f"{r.avg_rating if r.avg_rating is not None else 'n/a'}. Volume is {r.growth}x the previous 8-week rate"
                         + (f"; {int(r.segment_share*100)}% mention {r.top_segment}." if r.top_segment else ".")),
        "possible_trigger": (f"Increase began week of {r.spike_week:%d %b %Y}, shortly after release {r.possible_trigger}. "
                             "This is a correlation, not a confirmed root cause." if r.possible_trigger else
                             (f"Spike detected week of {r.spike_week:%d %b %Y}." if pd.notna(r.spike_week) else "No clear spike; long-running issue.")),
        "recommended_investigation": NEXT_STEP.get(r.area, "Review the evidence with the owning team and reproduce the issue."),
        "confidence": r.confidence,
    }
    if r.top_user_share > 0.3:
        txt["what_we_know"] += f" ⚠ {int(r.top_user_share*100)}% of messages come from ONE user — volume overstates reach."
    return txt


def llm_insight(r, quotes):
    """Optional: ask Claude for a richer summary (set ANTHROPIC_API_KEY)."""
    try:
        import anthropic
        if not os.getenv("ANTHROPIC_API_KEY"):
            return None
        stats = {k: (str(v) if not isinstance(v, (int, float)) else v) for k, v in r.items()
                 if k in ("area", "records", "unique_users", "severity", "growth", "top_segment", "segment_share", "possible_trigger", "avg_rating")}
        msg = anthropic.Anthropic().messages.create(
            model=os.getenv("FEEDBACKLENS_MODEL", "claude-sonnet-5"), max_tokens=400,
            messages=[{"role": "user", "content": "You are a product analyst. Using ONLY these stats and quotes, write: "
                       "1) a one-line problem statement, 2) likely root-cause hypotheses (clearly marked as hypotheses), "
                       "3) the next 2 investigation steps. Be concise.\nSTATS: " + json.dumps(stats) +
                       "\nQUOTES:\n- " + "\n- ".join(quotes)}])
        return msg.content[0].text
    except Exception as e:
        return f"(LLM unavailable: {e})"


def run(df, weights=None, threshold=0.93, reviews=None):
    df = apply_reviews(understand(df), reviews)
    df, X = cluster(df, threshold=threshold)
    info = label_issues(df, X)
    issues = build_issues(df, info, weights)
    return df, issues


if __name__ == "__main__":
    d, iss = run(pd.read_csv("data/sample_feedback.csv", dtype={"rating": object}))
    cols = ["priority_rank", "title", "records", "unique_users", "severity", "growth", "possible_trigger", "priority", "volume_rank"]
    print(iss[iss.kind == "problem"][cols].head(15).to_string(index=False))
