"""Generate a realistic, messy demo dataset (reviews, support chats, surveys, social posts).

Built-in story for the demo:
  * Release v4.2 (2026-08-20) breaks UPI payments -> payment complaints spike.
  * One "loud" user posts 45 angry messages about font size (low severity).
  * Many different users quietly report real problems once each.
"""
import random, csv, os
from datetime import datetime, timedelta

random.seed(42)
START, END = datetime(2026, 6, 1), datetime(2026, 9, 20)
RELEASES = [("v4.0", datetime(2026, 6, 1)), ("v4.1", datetime(2026, 7, 15)), ("v4.2", datetime(2026, 8, 20))]

# theme -> (templates, base weight per day, multiplier after v4.2, rating range)
THEMES = {
    "upi_fail": ([
        "UPI payment failed again", "gpay not working", "Unable to pay through GPay", "phonepe payment keeps failing",
        "Payment failed 😡", "upi isnt working since update", "Why payment is not going?", "Google pay failed 3 times",
        "payment nahi ho raha UPI se", "Transaction failed twice", "Payment doesn't work after update",
        "UPI failed three times, fix it", "can't pay with upi anymore", "paymnt failed with gpay"], 1.2, 5.0, (1, 2)),
    "money_deducted": ([
        "money deducted but order failed", "Amount debited but order not placed!!", "payment deducted but order cancelled",
        "I was charged but no order confirmation", "money gone from bank, order failed, need refund",
        "charged twice for the same order", "refund not received for failed payment"], 0.5, 3.5, (1, 1)),
    "checkout_slow": ([
        "checkout keeps loading...", "Why does checkout keep loading?", "checkout payment stuck on spinner",
        "Latest update made checkout extremely slow", "place order button takes forever", "cart to checkout is so slow"], 0.8, 2.2, (1, 3)),
    "otp_login": ([
        "OTP never arrives", "can't login", "otp not received, cant sign in", "Login keeps failing with correct password",
        "logged out randomly and cannot log back in", "OTP comes after 5 minutes, already expired"], 1.4, 1.0, (1, 2)),
    "crash": ([
        "App crashes when I open it", "app closes when I sign in", "crashes on the product page", "app freezes and crashes",
        "keeps crashing on android"], 1.0, 0.8, (1, 2)),
    "delivery_late": ([
        "delivery was late by 3 days", "order delivered late again", "tracking not updating, delivery delayed",
        "courier never came, delivery late"], 0.9, 1.0, (2, 3)),
    "notif_spam": ([
        "too many notifications, stop spamming", "notification spam every hour", "please reduce promotional notifications"], 0.6, 1.0, (2, 3)),
    "search": ([
        "search results are irrelevant", "search doesn't find products I know exist", "search filter not working properly"], 0.6, 1.0, (2, 3)),
    "dark_mode": ([
        "please add dark mode", "would be nice to have dark mode", "dark mode request!"], 0.4, 1.0, (3, 4)),
    "praise": ([
        "Love the new UI", "great app, fast delivery", "The new dashboard is amazing!", "best shopping app 👍",
        "I love the app, but payment sometimes fails", "super smooth experience"], 1.5, 1.0, (4, 5)),
    "vague": (["Worst experience", "App is slow", "worst app ever", "not happy", "It worked yesterday but not today"], 0.7, 1.0, (1, 2)),
}
LOUD_USER_MSGS = ["YOUR APP IS TERRIBLE!!! font too small", "FONT SIZE IS TOO SMALL!!!", "fix the tiny font 😡😡",
                  "font is unreadable, terrible app!!!", "I HATE THE FONT SIZE"]
EMOJI = ["😡", "😭", "🙄", "😤", "👎", ""]


def messify(t, positive=False):
    r = random.random()
    if r < 0.12: t = t.upper()
    elif r < 0.45: t = t.lower()
    if random.random() < 0.12:  # typo: drop a char in a random word
        w = t.split(); i = random.randrange(len(w))
        if len(w[i]) > 4:
            j = random.randrange(1, len(w[i]) - 1); w[i] = w[i][:j] + w[i][j + 1:]
        t = " ".join(w)
    if random.random() < 0.25: t += random.choice(["!!", "!!!", "..."] + ([] if positive else [" pls fix", " 🙏"]))
    if random.random() < 0.25: t += " " + random.choice(["👍", "😍", "🔥"] if positive else EMOJI)
    return t.strip()


def version_on(d):
    return [v for v, rd in RELEASES if rd <= d][-1]


def as_chat(text):
    follow = random.choice(["I tried three times.", "Please help asap.", "This is urgent.", "yes, same error again"])
    return f"User: {text} | Agent: Sorry to hear that. Can you share more details? | User: {follow}"


def main(out="data/sample_feedback.csv"):
    os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
    users = [f"U{n:05d}" for n in range(1, 4001)]
    rows, rid, d = [], 1, START
    while d <= END:
        after = d >= RELEASES[-1][1]
        for theme, (tpls, w, mult, (rlo, rhi)) in THEMES.items():
            lam = 4 * w * (mult if after else 1.0) * random.uniform(0.6, 1.4)
            for _ in range(int(lam) + (random.random() < lam % 1)):
                ts = d + timedelta(minutes=random.randint(0, 1439))
                text = messify(random.choice(tpls), positive=(theme == "praise"))
                src = random.choices(["app_review", "support_chat", "survey", "social"], [0.45, 0.2, 0.15, 0.2])[0]
                rating = random.randint(rlo, rhi) if src in ("app_review", "survey") else ""
                if src == "support_chat": text = as_chat(text)
                rows.append([f"F{rid:05d}", random.choice(users), src, ts.isoformat(timespec="minutes"), rating,
                             text, version_on(ts), random.choice(["android", "android", "ios"]), theme])
                rid += 1
        d += timedelta(days=1)
    # the loudest complainer: 45 messages, one person, low-severity issue
    for _ in range(45):
        ts = START + timedelta(minutes=random.randint(0, int((END - START).total_seconds() // 60)))
        rows.append([f"F{rid:05d}", "U_LOUD_001", random.choice(["app_review", "social", "support_chat"]),
                     ts.isoformat(timespec="minutes"), 1, messify(random.choice(LOUD_USER_MSGS)), version_on(ts), "ios", "font"])
        rid += 1
    # rating-only records (no text)
    for _ in range(80):
        ts = START + timedelta(minutes=random.randint(0, int((END - START).total_seconds() // 60)))
        rows.append([f"F{rid:05d}", random.choice(users), "app_review", ts.isoformat(timespec="minutes"),
                     random.randint(1, 5), "", version_on(ts), "android", "rating_only"])
        rid += 1
    rows.sort(key=lambda r: r[3])
    with open(out, "w", newline="", encoding="utf-8") as f:
        wr = csv.writer(f)
        wr.writerow(["feedback_id", "user_id", "source", "timestamp", "rating", "text", "app_version", "platform"])
        wr.writerows([r[:8] for r in rows])
    print(f"Wrote {len(rows)} records -> {out}")
    make_customers(rows, users + ["U_LOUD_001"], os.path.join(os.path.dirname(out) or ".", "customers.csv"))


# ---------------------------------------------------------------- customer activity (for churn & revenue prediction)
# How much each experienced problem raises the chance a customer leaves (log-odds). Hidden from the model:
# the model has to LEARN these effects from the labelled history.
CHURN_EFFECT = {"money_deducted": 2.0, "upi_fail": 1.3, "checkout_slow": 0.8, "otp_login": 0.7, "crash": 0.7,
                "delivery_late": 0.5, "vague": 0.6, "search": 0.3, "notif_spam": 0.2, "dark_mode": 0.0,
                "font": 0.1, "praise": -0.6, "rating_only": 0.0}
LABEL_WINDOW_DAYS = 30   # churn is only known 30 days after a customer's last feedback


def make_customers(rows, users, out):
    import math
    rng = random.Random(7)          # separate generator -> feedback data stays identical
    seen, last = {}, {}
    for r in rows:
        seen.setdefault(r[1], set()).add(r[8]); last[r[1]] = max(last.get(r[1], ""), r[3])
    cutoff = (END - timedelta(days=LABEL_WINDOW_DAYS)).isoformat()
    out_rows = []
    for u in users:
        tenure = rng.randint(20, 900)
        orders_90d = max(0, int(rng.lognormvariate(1.2, 0.7)))
        aov = round(rng.lognormvariate(6.4, 0.45))            # ~₹600 average order value
        z = -2.3 - 0.12 * orders_90d + (0.5 if tenure < 90 else 0) + rng.gauss(0, 0.4)
        z += sum(CHURN_EFFECT.get(t, 0) for t in seen.get(u, ()))
        churned = int(rng.random() < 1 / (1 + math.exp(-z)))
        label = "" if last.get(u, "") > cutoff else churned   # recent complainers: outcome not known yet
        out_rows.append([u, tenure, orders_90d, aov, label])
    with open(out, "w", newline="", encoding="utf-8") as f:
        wr = csv.writer(f)
        wr.writerow(["user_id", "tenure_days", "orders_90d", "avg_order_value", "churned"])
        wr.writerows(out_rows)
    print(f"Wrote {len(out_rows)} customers -> {out}")


if __name__ == "__main__":
    main()
