"""Start the whole FeedbackLens ecosystem with one command:
    python run_all.py            -> same Wi-Fi / hotspot (phones open http://<laptop-ip>:8502)
    python run_all.py --public   -> any network, via free Cloudflare tunnel links (needs 'cloudflared' installed)
Everything runs on THIS laptop. Press Ctrl+C to stop everything."""
import os, re, subprocess, sys, time, shutil
os.chdir(os.path.dirname(os.path.abspath(__file__)))  # so files + theme are always found
import db
from network import all_ips, lan_ip

VERSION = "2.5"
db.init_db()
py, env = sys.executable, os.environ.copy()
procs = []


def windows_firewall():
    """Allow the 4 ports through Windows Firewall (needs admin once). Returns a status line."""
    if os.name != "nt":
        return ""
    if subprocess.run('netsh advfirewall firewall show rule name="FeedbackLens"', shell=True,
                      capture_output=True).returncode == 0:
        return "✅ Windows Firewall rule 'FeedbackLens' is in place."
    r = subprocess.run('netsh advfirewall firewall add rule name="FeedbackLens" dir=in action=allow '
                       'protocol=TCP localport=8000,8501,8502,8503 profile=any', shell=True, capture_output=True)
    if r.returncode == 0:
        return "✅ Added Windows Firewall rule 'FeedbackLens'."
    return ("⚠️  Could not open the firewall (needs admin). Double-click 'allow_firewall_windows.bat' once,\n"
            "    click Yes, then restart this. Until then phones/other laptops can't connect.")


def start_tunnel(port):
    exe = shutil.which("cloudflared") or (os.path.exists("cloudflared.exe") and os.path.abspath("cloudflared.exe"))
    if not exe:
        return None
    p = subprocess.Popen([exe, "tunnel", "--no-autoupdate", "--url", f"http://localhost:{port}"],
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    procs.append(p)
    end = time.time() + 40
    while time.time() < end:
        line = p.stdout.readline()
        m = re.search(r"https://[-a-z0-9]+\.trycloudflare\.com", line or "")
        if m:
            return m.group(0)
    return None


public = "--public" in sys.argv
tunnel_note = ""
if public:
    print("Starting public tunnel links (takes ~10 s)…")
    for port in (8502, 8503):
        u = start_tunnel(port)
        if u:
            env[f"URL_{port}"] = u
    if "URL_8502" not in env:
        tunnel_note = ("⚠️  'cloudflared' not found. Install it (Windows: winget install --id Cloudflare.cloudflared)\n"
                       "    or put cloudflared.exe in this folder, then run again with --public.")

fw = windows_firewall()
st = [py, "-m", "streamlit", "run"]
opts = ["--server.address", "0.0.0.0", "--server.headless", "true",   # 0.0.0.0 = reachable from other devices
        "--server.enableCORS", "false", "--server.enableXsrfProtection", "false",  # allow browsers on other devices
        "--client.toolbarMode", "minimal", "--theme.base", "light",               # Deep Berry + Vanilla Cloud theme
        "--theme.primaryColor", "#FC6C26", "--theme.backgroundColor", "#FFF8DF",
        "--theme.secondaryBackgroundColor", "#FFEFC2", "--theme.textColor", "#3B2A1E"]
procs += [subprocess.Popen([py, "-m", "uvicorn", "api:app", "--host", "0.0.0.0", "--port", "8000"], env=env),
          subprocess.Popen(st + ["app.py", "--server.port", "8501"] + opts, env=env),
          subprocess.Popen(st + ["appbazaar.py", "--server.port", "8502"] + opts, env=env),
          subprocess.Popen(st + ["feedback_form.py", "--server.port", "8503"] + opts, env=env)]


def reachable(host, port):
    import requests
    try:
        return requests.get(f"http://{host}:{port}/_stcore/health", timeout=3,
                            proxies={"http": None, "https": None}).ok
    except Exception:
        return False


for _ in range(30):  # wait until the apps answer (max ~30 s)
    if reachable("localhost", 8502):
        break
    time.sleep(1)

ip = lan_ip()
share = env.get("URL_8502") or f"http://{ip}:8502"
checks = "\n".join(f"   {'✅' if reachable(a, 8502) else '❌'} http://{a}:8502" for a in all_ips()) or "   (no Wi-Fi/LAN address found)"
print(f"""
================================================================
 FeedbackLens v{VERSION} is running.

 On THIS laptop (always works):
   FeedbackLens dashboard   http://localhost:8501
   AppBazaar                http://localhost:8502

 For phones / other laptops:
   AppBazaar                {share}
   FeedbackForm             links + QR codes in FeedbackLens → 📝 Feedback Forms

 Network addresses of this laptop (self-test):
{checks}
 {fw}
 {tunnel_note}
 Scan to open AppBazaar on a phone:""")
try:
    import qrcode
    q = qrcode.QRCode(border=1); q.add_data(share); q.print_ascii(invert=True)
except Exception:
    pass
print(""" Phone can't connect?  1) Same Wi-Fi as the laptop (college/office Wi-Fi often blocks this → use your
 phone's hotspot)  2) run allow_firewall_windows.bat once  3) or restart with:  python run_all.py --public
================================================================""")
try:
    while all(p.poll() is None for p in procs[-4:]):
        time.sleep(1)
except KeyboardInterrupt:
    pass
finally:
    for p in procs:
        p.terminate()
