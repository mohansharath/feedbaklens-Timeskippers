"""FeedbackLens tabs: 👨‍💼 Human Review (human-in-the-loop) and 📝 Feedback Forms (form builder + QR)."""
import io, os
import pandas as pd
import plotly.express as px
import streamlit as st
import db
import pipeline as P
from theme import BERRY
import network as NET

SEV = {0: "None (praise)", 1: "Low", 2: "Medium", 3: "High", 4: "Critical"}
REJECT_REASONS = ["Support request (not a product issue)", "Spam / abuse", "Not actionable", "Duplicate"]
NEW_CAT = "➕ New category…"


# ================================================================ HUMAN REVIEW
def review_tab(df, issues):
    st.subheader("👨‍💼 Human Review — AI suggests, human verifies")
    st.caption("The AI reads everything. Only messages where it is **unsure** (confidence < "
               f"{int(P.REVIEW_THRESHOLD*100)}%) or where a **critical** call is not certain come here.")
    reviews = db.get_reviews()
    done = set(reviews.feedback_id)
    textual = df[df.canon != ""]
    flagged = textual[textual.needs_review | textual.feedback_id.isin(done)]
    queue = df[df.needs_review & ~df.feedback_id.isin(done)].sort_values(["severity", "ai_confidence"], ascending=[False, True])

    k = st.columns(4)
    k[0].metric("🤖 Handled by AI automatically", f"{len(textual) - len(flagged):,}",
                f"{(len(textual) - len(flagged)) / max(1, len(textual)):.0%} of messages", delta_color="off")
    k[1].metric("🚩 Sent to a human", f"{len(flagged):,}")
    k[2].metric("✅ Reviewed", f"{len(done):,}")
    k[3].metric("⏳ Waiting", f"{len(queue):,}")

    last = st.session_state.pop("last_review", None)
    if last:
        _review_complete(last)

    left, right = st.columns([3, 2], gap="large")
    with left:
        if queue.empty:
            st.success("🎉 Review queue is empty.")
        else:
            reason_filter = st.selectbox("Show", ["All uncertain items"] + sorted(
                {r for x in queue.conf_reasons for r in x.split("; ")}))
            q = queue if reason_filter.startswith("All") else queue[queue.conf_reasons.str.contains(reason_filter, regex=False)]
            pos = st.session_state.get("rq_pos", 0) % max(1, len(q))
            _review_card(df, q.iloc[pos], q, pos)
    with right:
        _ai_vs_human(reviews)


def _review_card(df, item, q, pos):
    fid = item.feedback_id
    with st.container(border=True):
        st.markdown(f"**Feedback {fid}**  ·  item {pos + 1} of {len(q)}")
        st.markdown(f"> “{item.text}”")
        stars = "★" * int(item.rating) if item.rating == item.rating else "no rating"
        st.caption(f"{item.source} · {item.user_id} · {item.timestamp:%d %b %Y} · {stars}")
        st.markdown("---\n**🤖 AI decision**")
        c = st.columns(3)
        c[0].markdown(f"Category  \n**{item.ai_area}**")
        c[1].markdown(f"Severity  \n**{SEV[int(item.ai_severity)]}**")
        c[2].markdown(f"Confidence  \n**{item.ai_confidence:.0%}**")
        st.warning(f"⚠️ AI is not sure: {item.conf_reasons}. Please review.")

        st.markdown("**👨‍💼 Human decision**")
        choice = st.radio("Decision", ["✅ Accept AI decision", "✏️ Change category / severity", "❌ Reject — not a product issue"],
                          key=f"ch_{fid}", label_visibility="collapsed")
        h_area, h_sev, reason = item.ai_area, int(item.ai_severity), ""
        if choice.startswith("✏️"):
            opts = P.HUMAN_AREAS + [NEW_CAT]
            a, b = st.columns(2)
            h_area = a.selectbox("Correct category", opts, index=opts.index(item.ai_area) if item.ai_area in opts else 0, key=f"ar_{fid}")
            if h_area == NEW_CAT:
                h_area = a.text_input("New category name", placeholder="e.g. Order Creation", key=f"nc_{fid}").strip() or item.ai_area
            h_sev = b.selectbox("Correct severity", list(SEV)[1:], index=max(0, h_sev - 1), format_func=SEV.get, key=f"sv_{fid}")
        elif choice.startswith("❌"):
            reason = st.selectbox("Why?", REJECT_REASONS, key=f"rj_{fid}")
        note = st.text_input("Note (optional)", placeholder="e.g. Payment succeeded; the order was not created", key=f"nt_{fid}")

        same = q[(q.issue_id == item.issue_id) & (q.ai_area == item.ai_area) & (q.feedback_id != fid)] if item.issue_id >= 0 else q.iloc[0:0]
        bulk = st.checkbox(f"Also apply to {len(same)} similar messages in the same issue cluster", key=f"bk_{fid}",
                           disabled=same.empty, help="One decision, many messages. Each gets its own audit record.")
        b1, b2 = st.columns([1, 1])
        if b1.button("Submit review", type="primary", width="stretch", key=f"sb_{fid}"):
            action = "accepted" if choice.startswith("✅") else "edited" if choice.startswith("✏️") else "rejected"
            targets = pd.concat([item.to_frame().T, same]) if bulk else item.to_frame().T
            rows = [{"feedback_id": t.feedback_id, "ai_area": t.ai_area, "ai_severity": int(t.ai_severity),
                     "ai_confidence": float(t.ai_confidence), "action": action,
                     "human_area": h_area if action == "edited" else (None if action == "rejected" else t.ai_area),
                     "human_severity": h_sev if action == "edited" else None,
                     "reason": " | ".join(x for x in [reason, note, "" if t.feedback_id == fid else f"bulk from {fid}"] if x)}
                    for _, t in targets.iterrows()]
            db.add_reviews(rows)
            st.session_state.last_review = {**rows[0], "n": len(rows), "text": item.text, "reject_reason": reason}
            st.rerun()
        if b2.button("Skip →", width="stretch", key=f"sk_{fid}"):
            st.session_state.rq_pos = pos + 1; st.rerun()


def _review_complete(r):
    with st.container(border=True):
        st.markdown(f"### ✅ Review complete — {r['feedback_id']}" + (f" (+{r['n']-1} similar)" if r["n"] > 1 else ""))
        ai = f"{r['ai_area']} · {SEV[r['ai_severity']]} · {r['ai_confidence']:.0%} confident"
        if r["action"] == "accepted":
            human, final = "Agreed with AI", r["ai_area"]
        elif r["action"] == "edited":
            human = f"{r['human_area']} · {SEV[r['human_severity']]}"; final = r["human_area"]
        else:
            human, final = f"Rejected — {r['reject_reason']}", "Excluded from product priorities"
        c = st.columns([3, 1, 3, 1, 3])
        c[0].markdown(f"**🤖 AI decision**  \n{ai}"); c[1].markdown("### →")
        c[2].markdown(f"**👨‍💼 Human**  \n{human}"); c[3].markdown("### →")
        c[4].markdown(f"**✅ Final decision**  \n**{final}**")
        st.caption("Both answers are stored. The final decision is used in prioritisation on the next **Process** "
                   "(or instantly in ⚡ Realtime mode).")


def _ai_vs_human(reviews):
    st.markdown("#### 🤖 vs 👨‍💼 How often do humans agree with the AI?")
    if reviews.empty:
        st.info("No reviews yet. Decisions you make appear here.")
        return
    counts = reviews.action.value_counts().reindex(["accepted", "edited", "rejected"], fill_value=0)
    lab = {"accepted": "AI accepted", "edited": "AI corrected", "rejected": "AI rejected"}
    d = pd.DataFrame({"decision": [lab[k] for k in counts.index], "count": counts.values})
    d["share"] = (d["count"] / d["count"].sum()).map("{:.0%}".format)
    fig = px.bar(d, x="count", y="decision", orientation="h", text="share", color_discrete_sequence=[BERRY],
                 labels={"count": "Reviewed messages", "decision": ""})
    fig.update_layout(height=190, margin=dict(l=0, r=10, t=5, b=0))
    st.plotly_chart(fig, width="stretch")
    st.caption(f"{len(reviews):,} messages reviewed by humans")
    ed = reviews[reviews.action == "edited"]
    if len(ed):
        st.markdown("**Where the AI was corrected**")
        st.dataframe(ed.groupby(["ai_area", "human_area"]).size().reset_index(name="times")
                     .sort_values("times", ascending=False).rename(columns={"ai_area": "AI said", "human_area": "Human said"}),
                     hide_index=True, width="stretch")
    with st.expander("Audit log (AI answer + human answer, never overwritten)"):
        st.dataframe(reviews.sort_values("review_id", ascending=False)[
            ["reviewed_at", "feedback_id", "ai_area", "ai_severity", "ai_confidence", "action", "human_area",
             "human_severity", "reason", "reviewer"]], hide_index=True, width="stretch")
        import exports
        st.download_button("⬇ Download reviews (Excel)", exports.to_excel({"Human reviews": exports.reviews_table(reviews)}),
                           "FeedbackLens - Human Reviews.xlsx", mime=exports.XLSX)


# ================================================================ FEEDBACK FORMS
def _qr_png(url):
    import qrcode
    buf = io.BytesIO(); qrcode.make(url, box_size=6, border=2).save(buf, format="PNG")
    return buf.getvalue()


def forms_tab():
    st.subheader("📝 Feedback Forms — collect feedback anywhere with a link or QR code")
    base = st.text_input("Form app address", os.getenv("FORM_BASE_URL") or NET.url(8503),
                         help="Auto-detected from your Wi-Fi. Phones must be on the same network (or use a tunnel URL).")
    apps = {a["app_id"]: a for a in db.list_apps()}
    with st.expander("➕ Create form", expanded=not db.list_forms()):
        with st.form("new_form"):
            app = st.selectbox("Product", list(apps), format_func=lambda k: f"{apps[k]['icon']} {apps[k]['name']}")
            title = st.text_input("Title", "ShopFlow Customer Feedback")
            desc = st.text_input("Description", "Tell us about your experience — it takes 30 seconds.")
            question = st.text_input("Question", "How was your experience?")
            areas = st.multiselect("Product areas customers can pick", [a for a, _ in P.AREAS],
                                   ["Payments", "Checkout", "Search", "Delivery", "UI & Design"])
            if st.form_submit_button("Generate form", type="primary"):
                fid = db.create_form(app, title, desc, question, areas)
                st.success(f"Form **{fid}** created.")
    for f in db.list_forms():
        url = f"{base.rstrip('/')}/?form={f['form_id']}"
        with st.container(border=True):
            a, b = st.columns([4, 1])
            a.markdown(f"**{f['title']}** · {apps.get(f['app_id'], {}).get('name', f['app_id'])}  \n"
                       f"`{f['form_id']}` · Status: {'🟢 Active' if f['active'] else '⚪ Off'} · "
                       f"**{f['responses']}** responses · created {f['created_at'][:10]}")
            a.code(url, language=None)
            a.link_button("Open form", url)
            b.image(NET.qr_png(url), caption="Scan to give feedback", width=140)
